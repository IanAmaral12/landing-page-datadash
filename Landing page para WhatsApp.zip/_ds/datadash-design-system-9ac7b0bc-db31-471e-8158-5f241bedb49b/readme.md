# DataDash Solutions — Design System

DataDash Solutions helps companies improve operations through process automation, CRM implementation (official **DataCrazy** partner), WhatsApp sales/service automation, AI agents, integrations/APIs, dashboards and custom software. Founder: **Ian Felipe Amaral Oliveira Silva (Ian Amaral)**, Full Stack developer. Audience: business owners and managers who need to organise service, follow sales opportunities, connect systems, cut manual work and see their numbers.

Primary surface: the institutional landing page (`ui_kits/website/`). All copy is **Brazilian Portuguese**.

## Sources
- `uploads/Screenshot 2026-10-22 145125.png` — original symbol with construction grid (indigo + black).
- `uploads/Screenshot 2026-10-22 145133.png` — original horizontal lockup "datadash." (indigo "data", black "dash.").
- `uploads/Left-Lit Silver DataDash Banner.png` — brushed-steel lockup on black (→ `assets/brand/banner-silver.png`).
- `uploads/Screenshot 2026-10-22 145139.png` — hero of https://fazer.ai/ (design reference; the site itself could not be fetched).
- Partner profile: https://partners.datacrazy.io/partners/ian-felipe-amaral-oliveira-silva-b2f10b · LinkedIn: https://www.linkedin.com/in/ian-felipe-silva/ (neither could be read; content comes from the brief).

## Index
- `styles.css` — entry; imports `tokens/fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `base.css`.
- `assets/logo/` — `symbol-*.png`, `lockup-*.png` (original lockup), `wordmark-*.png` in `primary · reverse · ink · white · indigo`. Extracted programmatically from the uploads (no redrawing).
- `assets/brand/banner-silver.png`, `assets/reference/`.
- `guidelines/` — foundation cards (Brand, Colors, Type, Spacing, Motion, Iconography).
- `components/` — React primitives (below).
- `ui_kits/website/` — landing page: `index.html` (desktop/responsive), `mobile.html` (390px frames), section JSX files, `site.css`, `boot.js`.
- `SKILL.md`, `thumbnail.html`.

## Components
Namespace: `window.DataDashDesignSystem_9ac7b0`.
- core: **Button**, **IconButton**, **Badge**, **Card**, **Logo**, **Icon**
- forms: **Field**, **Input**, **Textarea**, **Select**, **Checkbox**
- navigation: **Tabs**
- feedback: **Toast**, **Tooltip**

No component source existed, so this is a standard set sized to the website. Intentional additions: **Icon** (Lucide wrapper at brand stroke), **Logo** (asset path + lockup logic), **Field** (shared label/hint/error).

## Logo evolution
- **Kept:** the interlocking symbol exactly (two rounded loops = connection), the indigo/ink split, the lowercase "datadash." with the final dot.
- **Changed:** the wordmark is set in Lexend SemiBold (same single-storey geometry) instead of the traced outlines, whose curves were jagged at large sizes; tracking −3.5%; symbol–word gap fixed at 0.3× symbol height. This gives sharp rendering at any size and better small-size legibility.
- **Added:** a reverse version (indigo lifted to `#8577FF` + white) because `#1800AD` on black is only ~1.5:1; mono ink/white versions; clear space ½ symbol height; min 16px symbol / 20px lockup.
- The original raster lockup stays available (`<Logo variant="original">`).

## CONTENT FUNDAMENTALS
- **Language:** pt-BR, clear and calm. Speak to the reader as **você**/"sua empresa"; DataDash speaks as **nós** ("Implantamos", "Conversamos sobre a operação").
- **Tone:** competent, close, practical. Explain what is done and what changes. No guaranteed results, no unproven superlatives, no "revolucionar o futuro".
- **Structure per offer:** *O problema → Como atuamos → O que muda.* Problems are stated as concrete scenes ("Leads perdidos entre conversas e planilhas.").
- **Casing:** sentence case for headlines and buttons. Headlines end with a period ("Conecte seus processos."). Eyebrows in mono uppercase with a section number ("02 — Soluções").
- **Jargon:** explain on first use (Tooltip on "API": "Interface que permite dois sistemas trocarem dados").
- **Honesty rules:** every demo UI carries "Dados ilustrativos"; example scenarios are labelled "Exemplos ilustrativos" and never presented as cases. Never invent clients, numbers, certifications, testimonials, phone, e-mail or address — mark them "A definir".
- **CTAs:** "Conversar sobre meu projeto" (primary), "Conhecer as soluções" (secondary), "Iniciar conversa" (header, short).
- **Emoji:** never.

## VISUAL FOUNDATIONS
- **Color:** Indigo `#1800AD` (sampled from the logo) is the brand and the only CTA color. Ink `#0B0B12` and a silver scale (from the steel banner) carry the neutrals. Paper `#F5F4F0` is the light ground (warm, not white). **Signal lime `#C8F55A`** is reserved for live data: status dots, the "agora" tag, the new bar in a chart — never as text on light. Max one indigo full-bleed section per page.
- **Rhythm:** dark ink hero → paper sections → full-bleed indigo partner band → paper → white founder → ink contact → near-black footer.
- **Type:** Host Grotesk for everything (display 400 with −3.5% tracking, headings 400–500, body 400 at 16–19px / 1.55). Geist Mono for eyebrows, step numbers, data values and meta. Lexend only in the wordmark. Display sizes are fluid (`clamp`). Second sentence of a headline can drop to silver for emphasis.
- **Backgrounds:** flat colors. On dark sections, a faint 56px line grid (taken from the symbol's construction grid) masked with a radial fade, plus one soft indigo glow. No photos of robots, no gradients behind text, no textures besides the brand banner.
- **Graphic motif:** flows and connections — dashed connectors with a travelling signal dot, numbered nodes on a progress line, kanban columns, step cards.
- **Cards:** 20px radius, 1px hairline border (`--border-subtle`), `--shadow-1` resting. Dark cards: `--ink-850` with `rgba(255,255,255,.07)` border. Never a colored left border.
- **Radii:** 6 (checkbox) · 10 (inputs) · 14 (toast) · 20 (cards) · 28 (large panels) · pill (buttons, badges, tabs).
- **Shadows:** soft and low-contrast; hairline borders do most of the work. Demo UI on dark uses `--shadow-dark` with an inner top highlight.
- **Hover:** buttons lighten (indigo-700 → 600), trailing arrow nudges 3px; cards lift 2px and border darkens; problem rows fill their arrow chip with indigo and slide it 4px; nav links get a 7% white pill.
- **Press:** scale .98, indigo-800. **Focus:** 3px indigo ring `rgba(133,119,255,.45)`. **Disabled:** 42% opacity.
- **Transparency & blur:** only the sticky header once scrolled (ink 78% + 14px blur). No glassmorphism elsewhere.
- **Motion:** `cubic-bezier(.22,1,.36,1)`; 140/240/520/800ms. Sections reveal with fade + 16px rise, 60–80ms stagger. The hero flow cycles every 2.6s: WhatsApp message → CRM card enters "Qualificação" → automation creates the task → KPI ticks +1 and the last bar turns lime. The process line draws left→right (top→bottom on mobile) and fills each step dot. All motion respects `prefers-reduced-motion`.
- **Layout:** 1240px container, fluid gutter 20–48px, section padding 80–160px. Section heads: eyebrow on top, headline left, lead right; single column below 900px. Fixed element: header only.
- **Imagery:** real photos only (founder portrait). Cool/neutral, natural light. Until supplied, an image slot holds the place.

## ICONOGRAPHY
- **Set:** [Lucide](https://lucide.dev) 0.460.0 via CDN, through the `Icon` component (stroke 1.6, round caps/joins, `currentColor`). *Substitution:* no icon set came with the brand; Lucide's geometric, rounded line matches the symbol's rounded ends.
- **Sizes:** 14–16px in badges/small buttons, 18–20px inline, 22–26px in feature tiles (inside a 44–56px rounded square on `--indigo-50` or `--paper-2`).
- Common icons: `message-circle`, `square-kanban`, `workflow`, `bot`, `plug`, `chart-column`, `code-xml`, `list-checks`, `badge-check`, `arrow-right`, `arrow-up-right`, `linkedin`.
- No emoji, no icon fonts, no filled icons. Unicode `↗` is allowed in text links to external sites.

## Pending before publishing
- Commercial WhatsApp, e-mail (shown as "A definir"), CNPJ/legal name if required.
- Founder photo (drop into the image slot).
- Official DataCrazy partner badge/logo (currently text only).
- Brand font files if DataDash licenses a specific face (Google Fonts used: Host Grotesk, Geist Mono, Lexend).
- Form submission endpoint (form is a front-end mock).
