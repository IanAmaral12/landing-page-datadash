/* @ds-bundle: {"format":4,"namespace":"DataDashDesignSystem_9ac7b0","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"202850013a35","components/core/Button.jsx":"43250a266626","components/core/Card.jsx":"e69feb5d0dfa","components/core/Icon.jsx":"083587cb2fc3","components/core/IconButton.jsx":"8dfea946d9e1","components/core/Logo.jsx":"ba88abc9acfe","components/feedback/Toast.jsx":"b450d07d1f28","components/feedback/Tooltip.jsx":"35468488725f","components/forms/Checkbox.jsx":"42b6a974a80d","components/forms/Field.jsx":"9dbd17e961cf","components/forms/Input.jsx":"9a714bae4d15","components/forms/Select.jsx":"8e1ec9c5e688","components/forms/Textarea.jsx":"2870c247a6c8","components/navigation/Tabs.jsx":"65d58bd4f637","ui_kits/website/App.jsx":"a2d0dfb41987","ui_kits/website/Contact.jsx":"8e1db0781c3f","ui_kits/website/Examples.jsx":"c6e9bad87c8a","ui_kits/website/FlowDemo.jsx":"63877e36de7e","ui_kits/website/Footer.jsx":"7815d169b313","ui_kits/website/Founder.jsx":"dee0dbfac4e6","ui_kits/website/Header.jsx":"4f74c8844cbd","ui_kits/website/Hero.jsx":"87b69e161be2","ui_kits/website/Partner.jsx":"065f2227fe28","ui_kits/website/Problems.jsx":"ff1d8f8fd6ba","ui_kits/website/Process.jsx":"9aa2530d2174","ui_kits/website/Solutions.jsx":"2815c28cff0c","ui_kits/website/boot.js":"65f283f1d7b8","ui_kits/website/image-slot.js":"fff26d081c8d","ui_kits/website/shared.jsx":"1353c26d9126"},"inlinedExternals":[],"unexposedExports":[{"name":"fieldStyles","sourcePath":"components/forms/Field.jsx"}]} */

(() => {

const __ds_ns = (window.DataDashDesignSystem_9ac7b0 = window.DataDashDesignSystem_9ac7b0 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Card.jsx
try { (() => {
const SURF = {
  light: ['var(--surface-raised)', 'var(--border-subtle)', 'var(--text-body)'],
  sunken: ['var(--surface-sunken)', 'transparent', 'var(--text-body)'],
  dark: ['var(--dark-surface-card)', 'var(--dark-border-subtle)', 'var(--dark-text-body)'],
  brand: ['var(--indigo-700)', 'transparent', 'rgba(255,255,255,.82)']
};
function Card({
  children,
  surface = 'light',
  padding = 28,
  radius = 'var(--radius-l)',
  interactive = false,
  href,
  onClick,
  style
}) {
  const [hover, setHover] = React.useState(false);
  const [bg, bd, fg] = SURF[surface] || SURF.light;
  const dark = surface === 'dark' || surface === 'brand';
  const hb = interactive && hover ? dark ? 'var(--dark-border-strong)' : 'var(--border-strong)' : bd;
  const Tag = href ? 'a' : 'div';
  return React.createElement(Tag, {
    href,
    onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'block',
      position: 'relative',
      background: bg,
      color: fg,
      border: '1px solid ' + hb,
      borderRadius: radius,
      padding,
      textDecoration: 'none',
      boxShadow: surface === 'light' ? interactive && hover ? 'var(--shadow-2)' : 'var(--shadow-1)' : 'none',
      transform: interactive && hover ? 'translateY(-2px)' : 'none',
      transition: 'border-color var(--dur-base) var(--ease-out),box-shadow var(--dur-base) var(--ease-out),transform var(--dur-base) var(--ease-out)',
      cursor: interactive ? 'pointer' : 'default',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
const LUCIDE = 'https://unpkg.com/lucide@0.460.0/dist/umd/lucide.min.js';
let loading = null;
const subs = new Set();
function ensure() {
  if (typeof window === 'undefined' || window.lucide) return;
  if (!loading) {
    loading = document.createElement('script');
    loading.src = LUCIDE;
    loading.onload = () => subs.forEach(f => f());
    document.head.appendChild(loading);
  }
}
const pascal = n => n.replace(/(^|[-_ ])(\w)/g, (_, a, b) => b.toUpperCase());
function Icon({
  name,
  size = 20,
  strokeWidth = 1.6,
  color = 'currentColor',
  style,
  title
}) {
  const [, tick] = React.useState(0);
  React.useEffect(() => {
    if (window.lucide) return;
    const f = () => tick(t => t + 1);
    subs.add(f);
    ensure();
    return () => subs.delete(f);
  }, []);
  const node = typeof window !== 'undefined' && window.lucide && window.lucide.icons[pascal(name)];
  const kids = node ? (node[0] === 'svg' ? node[2] : node).map(([tag, attrs], i) => React.createElement(tag, {
    key: i,
    ...attrs
  })) : null;
  return React.createElement('svg', {
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: color,
    strokeWidth,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    'aria-hidden': title ? undefined : true,
    role: title ? 'img' : undefined,
    style: {
      flex: 'none',
      display: 'block',
      ...style
    }
  }, title ? React.createElement('title', null, title) : null, kids);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
const V = {
  neutral: {
    l: ['rgba(11,11,18,.05)', 'var(--text-body)', 'transparent'],
    d: ['rgba(255,255,255,.07)', 'var(--dark-text-body)', 'transparent']
  },
  outline: {
    l: ['transparent', 'var(--text-body)', 'var(--border-default)'],
    d: ['transparent', 'var(--dark-text-body)', 'var(--dark-border-default)']
  },
  brand: {
    l: ['var(--indigo-100)', 'var(--indigo-800)', 'transparent'],
    d: ['rgba(133,119,255,.16)', 'var(--indigo-300)', 'transparent']
  },
  signal: {
    l: ['var(--signal-500)', 'var(--signal-900)', 'transparent'],
    d: ['rgba(200,245,90,.12)', 'var(--signal-500)', 'transparent']
  },
  solid: {
    l: ['var(--ink-950)', '#fff', 'transparent'],
    d: ['#fff', 'var(--ink-950)', 'transparent']
  }
};
function Badge({
  children,
  variant = 'neutral',
  tone = 'light',
  icon,
  dot = false,
  live = false,
  mono = false,
  style
}) {
  const [bg, fg, bd] = (V[variant] || V.neutral)[tone === 'dark' ? 'd' : 'l'];
  return React.createElement('span', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      height: 28,
      padding: '0 12px',
      borderRadius: 'var(--radius-pill)',
      background: bg,
      color: fg,
      border: '1px solid ' + bd,
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
      fontSize: mono ? 11.5 : 13,
      fontWeight: 500,
      letterSpacing: mono ? '.06em' : '-.005em',
      textTransform: mono ? 'uppercase' : 'none',
      whiteSpace: 'nowrap',
      lineHeight: 1,
      ...style
    }
  }, dot ? React.createElement('span', {
    style: {
      width: 7,
      height: 7,
      borderRadius: 99,
      background: variant === 'signal' && tone !== 'dark' ? 'var(--signal-900)' : variant === 'brand' ? 'var(--indigo-500)' : 'var(--signal-500)',
      animation: live ? 'dd-pulse 2s infinite' : 'none'
    }
  }) : null, icon ? React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
const SIZES = {
  s: {
    h: 36,
    px: 16,
    fs: 14,
    ic: 16,
    gap: 6
  },
  m: {
    h: 46,
    px: 22,
    fs: 15,
    ic: 18,
    gap: 8
  },
  l: {
    h: 56,
    px: 28,
    fs: 16,
    ic: 18,
    gap: 10
  }
};
function palette(variant, tone, hover, press) {
  const dark = tone === 'dark';
  switch (variant) {
    case 'secondary':
      return dark ? {
        bg: hover ? 'rgba(255,255,255,.08)' : 'transparent',
        fg: 'var(--dark-text-strong)',
        bd: hover ? 'rgba(255,255,255,.5)' : 'var(--dark-border-strong)'
      } : {
        bg: hover ? 'rgba(11,11,18,.04)' : 'transparent',
        fg: 'var(--text-strong)',
        bd: hover ? 'rgba(11,11,18,.55)' : 'var(--border-strong)'
      };
    case 'inverse':
      return {
        bg: press ? 'var(--silver-200)' : hover ? 'var(--silver-100)' : 'var(--white)',
        fg: 'var(--ink-950)',
        bd: 'transparent'
      };
    case 'ghost':
      return dark ? {
        bg: hover ? 'rgba(255,255,255,.08)' : 'transparent',
        fg: 'var(--dark-text-strong)',
        bd: 'transparent'
      } : {
        bg: hover ? 'rgba(11,11,18,.05)' : 'transparent',
        fg: 'var(--text-strong)',
        bd: 'transparent'
      };
    default:
      return {
        bg: press ? 'var(--indigo-800)' : hover ? 'var(--indigo-600)' : 'var(--indigo-700)',
        fg: 'var(--white)',
        bd: 'transparent'
      };
  }
}
function Button({
  children,
  variant = 'primary',
  size = 'm',
  tone = 'light',
  iconLeft,
  iconRight,
  href,
  onClick,
  disabled = false,
  fullWidth = false,
  type = 'button',
  style
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.m;
  const p = palette(variant, tone, hover && !disabled, press && !disabled);
  const Tag = href ? 'a' : 'button';
  return React.createElement(Tag, {
    href,
    onClick: disabled ? undefined : onClick,
    type: href ? undefined : type,
    disabled: href ? undefined : disabled,
    'aria-disabled': disabled || undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: {
      display: fullWidth ? 'flex' : 'inline-flex',
      width: fullWidth ? '100%' : undefined,
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      height: s.h,
      padding: '0 ' + s.px + 'px',
      borderRadius: 'var(--radius-pill)',
      background: p.bg,
      color: p.fg,
      border: '1px solid ' + p.bd,
      fontFamily: 'var(--font-sans)',
      fontSize: s.fs,
      fontWeight: 500,
      letterSpacing: '-.005em',
      lineHeight: 1,
      whiteSpace: 'nowrap',
      textDecoration: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .42 : 1,
      transform: press && !disabled ? 'scale(.98)' : 'none',
      transition: 'background var(--dur-fast) var(--ease-out),border-color var(--dur-fast) var(--ease-out),transform var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, iconLeft ? React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.ic
  }) : null, React.createElement('span', null, children), iconRight ? React.createElement('span', {
    style: {
      display: 'inline-flex',
      transform: hover && !disabled ? 'translateX(3px)' : 'none',
      transition: 'transform var(--dur-base) var(--ease-out)'
    }
  }, React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.ic
  })) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function IconButton({
  icon,
  label,
  size = 44,
  variant = 'outline',
  tone = 'light',
  onClick,
  href,
  style
}) {
  const [hover, setHover] = React.useState(false);
  const dark = tone === 'dark';
  const bg = variant === 'solid' ? hover ? 'var(--indigo-600)' : 'var(--indigo-700)' : hover ? dark ? 'rgba(255,255,255,.1)' : 'rgba(11,11,18,.05)' : 'transparent';
  const fg = variant === 'solid' ? '#fff' : dark ? 'var(--dark-text-strong)' : 'var(--text-strong)';
  const bd = variant === 'solid' || variant === 'ghost' ? 'transparent' : dark ? 'var(--dark-border-default)' : 'var(--border-default)';
  const Tag = href ? 'a' : 'button';
  return React.createElement(Tag, {
    href,
    onClick,
    'aria-label': label,
    title: label,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: size,
      height: size,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-pill)',
      background: bg,
      color: fg,
      border: '1px solid ' + bd,
      cursor: 'pointer',
      padding: 0,
      transition: 'background var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, React.createElement(__ds_scope.Icon, {
    name: icon,
    size: Math.round(size * 0.42)
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
function base() {
  if (typeof document === 'undefined') return '';
  const s = [...document.scripts].find(x => /_ds_bundle\.js/.test(x.src));
  return s ? s.src.replace(/_ds_bundle\.js.*$/, '') : '';
}
const THEMES = {
  light: {
    sym: 'primary',
    data: 'var(--indigo-700)',
    dash: 'var(--ink-950)'
  },
  dark: {
    sym: 'reverse',
    data: 'var(--silver-300)',
    dash: '#fff'
  },
  ink: {
    sym: 'ink',
    data: 'var(--ink-950)',
    dash: 'var(--ink-950)'
  },
  white: {
    sym: 'white',
    data: '#fff',
    dash: '#fff'
  }
};
function Logo({
  variant = 'lockup',
  theme = 'light',
  height = 32,
  basePath,
  style
}) {
  const t = THEMES[theme] || THEMES.light;
  const b = basePath ?? base();
  const sym = React.createElement('img', {
    src: b + 'assets/logo/symbol-' + t.sym + '.png',
    alt: variant === 'symbol' ? 'DataDash' : '',
    style: {
      height,
      width: 'auto',
      display: 'block'
    }
  });
  if (variant === 'symbol') return React.createElement('span', {
    style: {
      display: 'inline-flex',
      ...style
    }
  }, sym);
  if (variant === 'original') return React.createElement('img', {
    src: b + 'assets/logo/lockup-' + t.sym + '.png',
    alt: 'DataDash',
    style: {
      height,
      width: 'auto',
      display: 'block',
      ...style
    }
  });
  return React.createElement('span', {
    role: 'img',
    'aria-label': 'DataDash',
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: height * 0.3,
      ...style
    }
  }, sym, React.createElement('span', {
    'aria-hidden': true,
    style: {
      fontFamily: 'var(--font-wordmark)',
      fontWeight: 600,
      fontSize: height * 1.12,
      letterSpacing: '-.035em',
      lineHeight: 1,
      transform: 'translateY(-0.04em)'
    }
  }, React.createElement('span', {
    style: {
      color: t.data
    }
  }, 'data'), React.createElement('span', {
    style: {
      color: t.dash
    }
  }, 'dash.')));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const ST = {
  success: ['circle-check', 'var(--signal-500)'],
  error: ['circle-alert', '#FF8A80'],
  info: ['info', 'var(--indigo-400)']
};
function Toast({
  title,
  message,
  status = 'success',
  onClose,
  style
}) {
  const [ic, col] = ST[status] || ST.info;
  return React.createElement('div', {
    role: 'status',
    style: {
      display: 'flex',
      gap: 14,
      alignItems: 'flex-start',
      width: '100%',
      maxWidth: 420,
      padding: '16px 16px 16px 18px',
      borderRadius: 'var(--radius-m)',
      background: 'var(--ink-900)',
      color: 'var(--dark-text-body)',
      border: '1px solid var(--dark-border-default)',
      boxShadow: 'var(--shadow-dark)',
      fontFamily: 'var(--font-sans)',
      animation: 'dd-rise var(--dur-slow) var(--ease-out)',
      ...style
    }
  }, React.createElement('span', {
    style: {
      color: col,
      marginTop: 1
    }
  }, React.createElement(__ds_scope.Icon, {
    name: ic,
    size: 20
  })), React.createElement('div', {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title ? React.createElement('div', {
    style: {
      color: '#fff',
      fontWeight: 500,
      fontSize: 15,
      marginBottom: message ? 3 : 0
    }
  }, title) : null, message ? React.createElement('div', {
    style: {
      fontSize: 14,
      lineHeight: 1.45
    }
  }, message) : null), onClose ? React.createElement('button', {
    onClick: onClose,
    'aria-label': 'Fechar',
    style: {
      background: 'none',
      border: 'none',
      color: 'var(--dark-text-muted)',
      cursor: 'pointer',
      padding: 2
    }
  }, React.createElement(__ds_scope.Icon, {
    name: 'x',
    size: 16
  })) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  content,
  children,
  placement = 'top'
}) {
  const [open, setOpen] = React.useState(false);
  const top = placement === 'top';
  return React.createElement('span', {
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    onFocus: () => setOpen(true),
    onBlur: () => setOpen(false),
    style: {
      position: 'relative',
      display: 'inline-flex'
    }
  }, children, React.createElement('span', {
    role: 'tooltip',
    style: {
      position: 'absolute',
      left: '50%',
      [top ? 'bottom' : 'top']: 'calc(100% + 8px)',
      transform: 'translateX(-50%) translateY(' + (open ? 0 : top ? 4 : -4) + 'px)',
      opacity: open ? 1 : 0,
      pointerEvents: 'none',
      background: 'var(--ink-950)',
      color: '#fff',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      lineHeight: 1.4,
      padding: '7px 10px',
      borderRadius: 8,
      whiteSpace: 'nowrap',
      boxShadow: 'var(--shadow-2)',
      transition: 'opacity var(--dur-fast) var(--ease-out),transform var(--dur-base) var(--ease-out)',
      zIndex: 20
    }
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked,
  defaultChecked = false,
  onChange,
  tone = 'light',
  disabled = false,
  id
}) {
  const [inner, setInner] = React.useState(defaultChecked);
  const on = checked ?? inner;
  const dark = tone === 'dark';
  const [hover, setHover] = React.useState(false);
  const toggle = () => {
    if (disabled) return;
    const v = !on;
    if (checked === undefined) setInner(v);
    onChange && onChange(v);
  };
  return React.createElement('label', {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'flex-start',
      gap: 12,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? .45 : 1,
      fontFamily: 'var(--font-sans)',
      fontSize: 14.5,
      lineHeight: 1.45,
      color: dark ? 'var(--dark-text-body)' : 'var(--text-body)'
    }
  }, React.createElement('input', {
    type: 'checkbox',
    id,
    checked: on,
    onChange: toggle,
    disabled,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 1,
      height: 1
    }
  }), React.createElement('span', {
    'aria-hidden': true,
    style: {
      flex: 'none',
      width: 20,
      height: 20,
      marginTop: 1,
      borderRadius: 6,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: on ? dark ? 'var(--indigo-500)' : 'var(--indigo-700)' : 'transparent',
      border: '1.5px solid ' + (on ? 'transparent' : hover ? dark ? 'rgba(255,255,255,.5)' : 'var(--ink-700)' : dark ? 'var(--dark-border-strong)' : 'var(--border-strong)'),
      color: '#fff',
      transition: 'background var(--dur-fast) var(--ease-out)'
    }
  }, on ? React.createElement(__ds_scope.Icon, {
    name: 'check',
    size: 14,
    strokeWidth: 2.4
  }) : null), label ? React.createElement('span', null, label) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function fieldStyles(tone, focus, error) {
  const dark = tone === 'dark';
  return {
    width: '100%',
    minHeight: 52,
    padding: '14px 16px',
    borderRadius: 'var(--radius-s)',
    fontFamily: 'var(--font-sans)',
    fontSize: 16,
    lineHeight: 1.4,
    outline: 'none',
    background: dark ? 'rgba(255,255,255,.04)' : 'var(--white)',
    color: dark ? 'var(--dark-text-strong)' : 'var(--text-strong)',
    border: '1px solid ' + (error ? 'var(--danger)' : focus ? dark ? 'var(--indigo-400)' : 'var(--indigo-700)' : dark ? 'var(--dark-border-default)' : 'var(--border-default)'),
    boxShadow: focus ? 'var(--focus-ring)' : 'none',
    transition: 'border-color var(--dur-fast) var(--ease-out),box-shadow var(--dur-fast) var(--ease-out)'
  };
}
function Field({
  label,
  hint,
  error,
  tone = 'light',
  htmlFor,
  required,
  children
}) {
  const dark = tone === 'dark';
  return React.createElement('label', {
    htmlFor,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      fontFamily: 'var(--font-sans)'
    }
  }, label ? React.createElement('span', {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: dark ? 'var(--dark-text-strong)' : 'var(--text-strong)'
    }
  }, label, required ? React.createElement('span', {
    style: {
      color: dark ? 'var(--indigo-400)' : 'var(--indigo-700)'
    }
  }, ' *') : null) : null, children, error || hint ? React.createElement('span', {
    style: {
      fontSize: 13,
      color: error ? dark ? '#FF8A80' : 'var(--danger)' : dark ? 'var(--dark-text-muted)' : 'var(--text-muted)'
    }
  }, error || hint) : null);
}
Object.assign(__ds_scope, { fieldStyles, Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function Input({
  label,
  hint,
  error,
  tone = 'light',
  required,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || React.useId();
  return React.createElement(__ds_scope.Field, {
    label,
    hint,
    error,
    tone,
    required,
    htmlFor: fid
  }, React.createElement('input', {
    id: fid,
    required,
    'aria-invalid': !!error,
    ...rest,
    onFocus: e => {
      setFocus(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocus(false);
      rest.onBlur && rest.onBlur(e);
    },
    style: {
      ...__ds_scope.fieldStyles(tone, focus, error),
      ...style
    }
  }));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  label,
  hint,
  error,
  tone = 'light',
  required,
  id,
  options = [],
  placeholder,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || React.useId();
  return React.createElement(__ds_scope.Field, {
    label,
    hint,
    error,
    tone,
    required,
    htmlFor: fid
  }, React.createElement('span', {
    style: {
      position: 'relative',
      display: 'block'
    }
  }, React.createElement('select', {
    id: fid,
    required,
    ...rest,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      ...__ds_scope.fieldStyles(tone, focus, error),
      appearance: 'none',
      paddingRight: 44,
      cursor: 'pointer',
      ...style
    }
  }, placeholder ? React.createElement('option', {
    value: ''
  }, placeholder) : null, options.map(o => {
    const v = typeof o === 'string' ? o : o.value;
    const l = typeof o === 'string' ? o : o.label;
    return React.createElement('option', {
      key: v,
      value: v
    }, l);
  })), React.createElement('span', {
    style: {
      position: 'absolute',
      right: 16,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none',
      color: tone === 'dark' ? 'var(--dark-text-muted)' : 'var(--text-muted)'
    }
  }, React.createElement(__ds_scope.Icon, {
    name: 'chevron-down',
    size: 18
  }))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function Textarea({
  label,
  hint,
  error,
  tone = 'light',
  required,
  id,
  style,
  rows = 4,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || React.useId();
  return React.createElement(__ds_scope.Field, {
    label,
    hint,
    error,
    tone,
    required,
    htmlFor: fid
  }, React.createElement('textarea', {
    id: fid,
    rows,
    required,
    'aria-invalid': !!error,
    ...rest,
    onFocus: e => {
      setFocus(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocus(false);
      rest.onBlur && rest.onBlur(e);
    },
    style: {
      ...__ds_scope.fieldStyles(tone, focus, error),
      resize: 'vertical',
      ...style
    }
  }));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  defaultValue,
  onChange,
  tone = 'light',
  variant = 'pill',
  style
}) {
  const [inner, setInner] = React.useState(defaultValue ?? (items[0] && items[0].id));
  const cur = value ?? inner;
  const dark = tone === 'dark';
  const [hov, setHov] = React.useState(null);
  const pick = id => {
    if (value === undefined) setInner(id);
    onChange && onChange(id);
  };
  const pill = variant === 'pill';
  return React.createElement('div', {
    role: 'tablist',
    style: {
      display: 'inline-flex',
      flexWrap: 'wrap',
      gap: pill ? 4 : 28,
      padding: pill ? 4 : 0,
      borderRadius: 'var(--radius-pill)',
      background: pill ? dark ? 'rgba(255,255,255,.06)' : 'rgba(11,11,18,.05)' : 'transparent',
      borderBottom: pill ? 'none' : '1px solid ' + (dark ? 'var(--dark-border-default)' : 'var(--border-default)'),
      ...style
    }
  }, items.map(it => {
    const on = it.id === cur;
    const h = hov === it.id;
    const fg = on ? pill ? dark ? 'var(--ink-950)' : '#fff' : dark ? '#fff' : 'var(--text-strong)' : h ? dark ? '#fff' : 'var(--text-strong)' : dark ? 'var(--dark-text-muted)' : 'var(--text-muted)';
    return React.createElement('button', {
      key: it.id,
      role: 'tab',
      'aria-selected': on,
      onClick: () => pick(it.id),
      onMouseEnter: () => setHov(it.id),
      onMouseLeave: () => setHov(null),
      style: {
        height: pill ? 40 : 48,
        padding: pill ? '0 18px' : 0,
        border: 'none',
        cursor: 'pointer',
        fontFamily: 'var(--font-sans)',
        fontSize: 15,
        fontWeight: 500,
        letterSpacing: '-.01em',
        whiteSpace: 'nowrap',
        borderRadius: 'var(--radius-pill)',
        background: pill && on ? dark ? '#fff' : 'var(--ink-950)' : 'transparent',
        color: fg,
        boxShadow: !pill && on ? 'inset 0 -2px 0 ' + (dark ? 'var(--indigo-400)' : 'var(--indigo-700)') : 'none',
        transition: 'background var(--dur-base) var(--ease-out),color var(--dur-fast)'
      }
    }, it.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/App.jsx
try { (() => {
function App() {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Header, null), /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement(Hero, null), /*#__PURE__*/React.createElement(Problems, null), /*#__PURE__*/React.createElement(Solutions, null), /*#__PURE__*/React.createElement(Partner, null), /*#__PURE__*/React.createElement(Process, null), /*#__PURE__*/React.createElement(Founder, null), /*#__PURE__*/React.createElement(Examples, null), /*#__PURE__*/React.createElement(Contact, null)), /*#__PURE__*/React.createElement(Footer, null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Contact.jsx
try { (() => {
function Contact() {
  const {
    Input,
    Select,
    Textarea,
    Checkbox,
    Button,
    Badge,
    Toast
  } = DS;
  const [v, setV] = React.useState({
    nome: '',
    empresa: '',
    whats: '',
    interesse: '',
    msg: ''
  });
  const [ok, setOk] = React.useState(false);
  const [err, setErr] = React.useState({});
  const [toast, setToast] = React.useState(false);
  const [sending, setSending] = React.useState(false);
  const up = k => e => {
    setV({
      ...v,
      [k]: e.target.value
    });
    if (err[k]) setErr({
      ...err,
      [k]: null
    });
  };
  const submit = e => {
    e.preventDefault();
    const n = {};
    if (!v.nome.trim()) n.nome = 'Informe seu nome';
    if (v.whats.replace(/\D/g, '').length < 10) n.whats = 'Informe um número com DDD';
    if (!ok) n.ok = true;
    setErr(n);
    if (Object.keys(n).length) return;
    setSending(true);
    setTimeout(() => {
      setSending(false);
      setToast(true);
      setV({
        nome: '',
        empresa: '',
        whats: '',
        interesse: '',
        msg: ''
      });
      setOk(false);
      setTimeout(() => setToast(false), 5000);
    }, 900);
  };
  return /*#__PURE__*/React.createElement("section", {
    className: "sec dark",
    id: "contato",
    style: {
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gridbg",
    style: {
      WebkitMaskImage: 'radial-gradient(ellipse 60% 70% at 10% 90%,#000 10%,transparent 70%)',
      maskImage: 'radial-gradient(ellipse 60% 70% at 10% 90%,#000 10%,transparent 70%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "wrap contact-grid",
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Reveal, {
    className: "eyebrow"
  }, "07 \u2014 Contato"), /*#__PURE__*/React.createElement(Reveal, {
    delay: 60
  }, /*#__PURE__*/React.createElement("h2", {
    className: "h-display",
    style: {
      fontSize: 'var(--fs-display-l)',
      marginTop: 28
    }
  }, "Conte como sua opera\xE7\xE3o funciona hoje.")), /*#__PURE__*/React.createElement(Reveal, {
    delay: 120
  }, /*#__PURE__*/React.createElement("p", {
    className: "lead",
    style: {
      marginTop: 24
    }
  }, "Descreva o cen\xE1rio em poucas linhas. Com isso, preparamos uma primeira conversa objetiva sobre o que pode ser automatizado, integrado ou desenvolvido."), /*#__PURE__*/React.createElement("div", {
    className: "pend"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#fff'
    }
  }, "WhatsApp comercial"), /*#__PURE__*/React.createElement(Badge, {
    mono: true,
    variant: "outline",
    tone: "dark"
  }, "A definir")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#fff'
    }
  }, "E-mail"), /*#__PURE__*/React.createElement(Badge, {
    mono: true,
    variant: "outline",
    tone: "dark"
  }, "A definir")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#fff'
    }
  }, "LinkedIn"), /*#__PURE__*/React.createElement("a", {
    href: LINKEDIN_URL,
    style: {
      color: 'var(--indigo-300)'
    }
  }, "ian-felipe-silva \u2197"))))), /*#__PURE__*/React.createElement(Reveal, {
    delay: 160
  }, /*#__PURE__*/React.createElement("form", {
    className: "form",
    onSubmit: submit,
    noValidate: true
  }, /*#__PURE__*/React.createElement(Input, {
    tone: "dark",
    label: "Nome",
    required: true,
    placeholder: "Como podemos te chamar?",
    value: v.nome,
    onChange: up('nome'),
    error: err.nome
  }), /*#__PURE__*/React.createElement(Input, {
    tone: "dark",
    label: "Empresa",
    placeholder: "Nome da empresa",
    value: v.empresa,
    onChange: up('empresa')
  }), /*#__PURE__*/React.createElement(Input, {
    tone: "dark",
    label: "WhatsApp",
    required: true,
    type: "tel",
    placeholder: "(00) 00000-0000",
    value: v.whats,
    onChange: up('whats'),
    error: err.whats
  }), /*#__PURE__*/React.createElement(Select, {
    tone: "dark",
    label: "Principal interesse",
    placeholder: "Selecione",
    value: v.interesse,
    onChange: up('interesse'),
    options: ['CRM e atendimento', 'Implantação DataCrazy', 'Automações e integrações', 'Agentes de IA', 'Dados e dashboards', 'Software sob medida', 'Ainda não sei']
  }), /*#__PURE__*/React.createElement("div", {
    className: "full"
  }, /*#__PURE__*/React.createElement(Textarea, {
    tone: "dark",
    label: "Seu cen\xE1rio",
    rows: 4,
    hint: "Ex.: atendemos pelo WhatsApp e controlamos os pedidos em planilhas.",
    value: v.msg,
    onChange: up('msg')
  })), /*#__PURE__*/React.createElement("div", {
    className: "full"
  }, /*#__PURE__*/React.createElement(Checkbox, {
    tone: "dark",
    checked: ok,
    onChange: c => {
      setOk(c);
      setErr({
        ...err,
        ok: null
      });
    },
    label: /*#__PURE__*/React.createElement("span", {
      style: {
        color: err.ok ? '#FF8A80' : undefined
      }
    }, "Aceito ser contatado pela DataDash sobre este projeto.")
  })), /*#__PURE__*/React.createElement("div", {
    className: "full",
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 16,
      flexWrap: 'wrap',
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--dark-text-muted)'
    }
  }, "Campos com * s\xE3o obrigat\xF3rios."), /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    size: "l",
    iconRight: sending ? undefined : 'arrow-right',
    disabled: sending
  }, sending ? 'Enviando…' : 'Enviar e iniciar conversa'))))), toast && /*#__PURE__*/React.createElement("div", {
    className: "toast-host"
  }, /*#__PURE__*/React.createElement(Toast, {
    title: "Mensagem enviada",
    message: "Recebemos seu cen\xE1rio e vamos retornar pelo WhatsApp informado.",
    onClose: () => setToast(false)
  })));
}
window.Contact = Contact;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Contact.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Examples.jsx
try { (() => {
function Examples() {
  const {
    Card,
    Badge,
    Icon
  } = DS;
  const ex = [['store', 'Comércio com vendas pelo WhatsApp', 'Vendedores atendem em celulares próprios e não há registro das negociações.', 'WhatsApp integrado ao CRM, com funil de vendas e distribuição automática de contatos.', 'Histórico centralizado e visão de quantas negociações estão em cada etapa.'], ['calendar-check', 'Empresa de serviços com agenda cheia', 'A equipe passa parte do dia confirmando horários e respondendo dúvidas repetidas.', 'Agente de IA para dúvidas frequentes e lembretes automáticos de confirmação.', 'Menos tempo em tarefas repetitivas e menos faltas por esquecimento.'], ['sheet', 'Operação com dados em várias planilhas', 'Relatórios mensais montados à mão, com dados copiados de três sistemas.', 'Integração das fontes de dados e dashboard com os indicadores principais.', 'Números atualizados para a reunião de gestão, sem montagem manual.']];
  return /*#__PURE__*/React.createElement("section", {
    className: "sec",
    id: "exemplos"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sec-head"
  }, /*#__PURE__*/React.createElement(Reveal, {
    className: "eyebrow"
  }, "05 \u2014 Exemplos de aplica\xE7\xE3o"), /*#__PURE__*/React.createElement(Reveal, {
    delay: 60
  }, /*#__PURE__*/React.createElement("h2", {
    className: "h2"
  }, "Como isso pode funcionar na pr\xE1tica.")), /*#__PURE__*/React.createElement(Reveal, {
    delay: 120
  }, /*#__PURE__*/React.createElement(Badge, {
    mono: true,
    variant: "outline"
  }, "Exemplos ilustrativos"), /*#__PURE__*/React.createElement("p", {
    className: "lead",
    style: {
      marginTop: 14,
      fontSize: 16
    }
  }, "Cen\xE1rios comuns para mostrar o tipo de projeto que realizamos. N\xE3o representam clientes ou resultados reais."))), /*#__PURE__*/React.createElement("div", {
    className: "ex-grid"
  }, ex.map(([ic, t, a, b, c], k) => /*#__PURE__*/React.createElement(Reveal, {
    key: k,
    delay: k * 80
  }, /*#__PURE__*/React.createElement(Card, {
    interactive: true,
    padding: 28,
    style: {
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ex"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 44,
      height: 44,
      borderRadius: 12,
      background: 'var(--paper-2)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--ink-950)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 22
  })), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--text-muted)'
    }
  }, "EXEMPLO 0", k + 1)), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '24px 0 0',
      font: '500 21px/1.2 var(--font-display)',
      letterSpacing: '-.015em',
      color: 'var(--text-strong)'
    }
  }, t), /*#__PURE__*/React.createElement("dl", null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Cen\xE1rio"), /*#__PURE__*/React.createElement("dd", null, a)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Solu\xE7\xE3o poss\xEDvel"), /*#__PURE__*/React.createElement("dd", null, b)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Benef\xEDcio esperado"), /*#__PURE__*/React.createElement("dd", {
    style: {
      color: 'var(--text-strong)'
    }
  }, c))))))))));
}
window.Examples = Examples;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Examples.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/FlowDemo.jsx
try { (() => {
function FlowDemo() {
  const {
    Badge,
    Icon
  } = DS;
  const [i, setI] = React.useState(0);
  const [cycle, setCycle] = React.useState(0);
  const ref = React.useRef(null);
  const vis = useInView(ref, {
    threshold: .3
  });
  React.useEffect(() => {
    if (!vis) return;
    const t = setInterval(() => setI(x => {
      const n = (x + 1) % 4;
      if (n === 0) setCycle(c => c + 1);
      return n;
    }), 2600);
    return () => clearInterval(t);
  }, [vis]);
  const st = k => k === i ? 'step on' : k < i ? 'step done' : 'step';
  const H = ({
    n,
    icon,
    label
  }) => /*#__PURE__*/React.createElement("div", {
    className: "step-h"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 15
  }), n, " \xB7 ", label), n - 1 === i ? /*#__PURE__*/React.createElement(Badge, {
    variant: "signal",
    tone: "dark",
    dot: true,
    live: true,
    mono: true,
    style: {
      height: 22,
      padding: '0 8px',
      fontSize: 10
    }
  }, "agora") : null);
  const bars = [22, 30, 26, 38, 34, 44, i >= 3 ? 58 : 44];
  return /*#__PURE__*/React.createElement("div", {
    className: "flow",
    ref: ref
  }, /*#__PURE__*/React.createElement("div", {
    className: "flow-bar"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 12,
      letterSpacing: '.06em',
      textTransform: 'uppercase',
      color: 'var(--dark-text-muted)'
    }
  }, "Da conversa ao indicador"), /*#__PURE__*/React.createElement(Badge, {
    mono: true,
    variant: "outline",
    tone: "dark"
  }, "Dados ilustrativos")), /*#__PURE__*/React.createElement("div", {
    className: "flow-steps"
  }, /*#__PURE__*/React.createElement("div", {
    className: st(0),
    key: 'a' + cycle
  }, /*#__PURE__*/React.createElement(H, {
    n: 1,
    icon: "message-circle",
    label: "Atendimento"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 99,
      background: 'var(--ink-700)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 11.5,
      color: '#fff',
      fontWeight: 500
    }
  }, "MC"), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#fff',
      fontSize: 14,
      fontWeight: 500
    }
  }, "Marina C."), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--dark-text-muted)'
    }
  }, "WhatsApp \xB7 14:32"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "bubble"
  }, "Oi! Voc\xEAs fazem or\xE7amento para 3 unidades?"), /*#__PURE__*/React.createElement("div", {
    className: "pop",
    style: {
      animationDelay: '.9s',
      display: 'flex',
      alignItems: 'flex-end',
      gap: 8,
      alignSelf: 'flex-end',
      justifyContent: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "bubble me",
    style: {
      maxWidth: '100%'
    }
  }, "Fazemos sim! J\xE1 registrei seu pedido."), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none',
      width: 28,
      height: 28,
      borderRadius: 99,
      background: 'var(--ink-800)',
      border: '1px solid var(--dark-border-subtle)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/datinha/datinha-dark-ok.svg",
    alt: "Datinha",
    style: {
      width: '86%',
      height: '86%'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    className: "conn go"
  }, /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("b", {
    style: {
      animationDelay: '2.2s'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: st(1)
  }, /*#__PURE__*/React.createElement(H, {
    n: 2,
    icon: "square-kanban",
    label: "CRM"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 8,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "kcol"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 10,
      color: 'var(--dark-text-muted)',
      letterSpacing: '.06em'
    }
  }, "NOVO"), /*#__PURE__*/React.createElement("div", {
    className: "kcard"
  }, "Rafael T.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .6
    }
  }, "Site")), /*#__PURE__*/React.createElement("div", {
    className: "kcard"
  }, "Loja Sul", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .6
    }
  }, "Indica\xE7\xE3o"))), /*#__PURE__*/React.createElement("div", {
    className: "kcol"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 10,
      color: 'var(--dark-text-muted)',
      letterSpacing: '.06em'
    }
  }, "QUALIFICA\xC7\xC3O"), i >= 1 ? /*#__PURE__*/React.createElement("div", {
    className: "kcard hl pop",
    key: 'k' + cycle
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontWeight: 600
    }
  }, "Marina C."), /*#__PURE__*/React.createElement("br", null), "Or\xE7amento \xB7 3 un.", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 11.5
    }
  }, "R$ 4.800")) : null, /*#__PURE__*/React.createElement("div", {
    className: "kcard"
  }, "Grupo Alfa", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .6
    }
  }, "WhatsApp")))), /*#__PURE__*/React.createElement("div", {
    className: "conn go",
    key: 'c1' + cycle + (i >= 1)
  }, /*#__PURE__*/React.createElement("i", null), i === 1 && /*#__PURE__*/React.createElement("b", {
    style: {
      animationDelay: '1.6s'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: st(2)
  }, /*#__PURE__*/React.createElement(H, {
    n: 3,
    icon: "workflow",
    label: "Automa\xE7\xE3o"
  }), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 11.5,
      color: 'var(--dark-text-muted)',
      padding: '8px 10px',
      border: '1px dashed var(--dark-border-default)',
      borderRadius: 10
    }
  }, "quando etapa = Qualifica\xE7\xE3o"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, [['Criar tarefa “Enviar proposta”', 'list-checks'], ['Atribuir à equipe comercial', 'user-round'], ['Lembrete: hoje, 16:00', 'clock']].map(([t, ic], k) => /*#__PURE__*/React.createElement("div", {
    key: k + '-' + cycle + '-' + (i >= 2),
    className: i >= 2 ? 'pop' : '',
    style: {
      animationDelay: k * 180 + 'ms',
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      fontSize: 13.5,
      color: i >= 2 ? '#E9E9EE' : 'var(--dark-text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: 8,
      background: i >= 2 ? 'rgba(133,119,255,.18)' : 'var(--ink-700)',
      color: i >= 2 ? 'var(--indigo-300)' : 'var(--dark-text-muted)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 14
  })), t))), /*#__PURE__*/React.createElement("div", {
    className: "conn go",
    key: 'c2' + cycle + (i >= 2)
  }, /*#__PURE__*/React.createElement("i", null), i === 2 && /*#__PURE__*/React.createElement("b", {
    style: {
      animationDelay: '1.6s'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: st(3)
  }, /*#__PURE__*/React.createElement(H, {
    n: 4,
    icon: "chart-column",
    label: "Indicadores"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--dark-text-muted)',
      letterSpacing: '.04em'
    }
  }, "Oportunidades abertas"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 10,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 44px/1 var(--font-display)',
      letterSpacing: '-.03em',
      color: '#fff'
    }
  }, i >= 3 ? 25 : 24), i >= 3 && /*#__PURE__*/React.createElement("span", {
    className: "mono pop",
    style: {
      fontSize: 12,
      color: 'var(--signal-500)'
    }
  }, "+1 hoje"))), /*#__PURE__*/React.createElement("div", {
    className: "bars"
  }, bars.map((h, k) => /*#__PURE__*/React.createElement("i", {
    key: k,
    style: {
      height: h + 'px',
      background: k === 6 && i >= 3 ? 'var(--signal-500)' : undefined
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mono",
    style: {
      fontSize: 11,
      color: 'var(--dark-text-muted)',
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", null, "1\xAA resposta"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: '#E9E9EE'
    }
  }, "4 min")))));
}
window.FlowDemo = FlowDemo;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/FlowDemo.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
function Footer() {
  const {
    Logo,
    IconButton
  } = DS;
  return /*#__PURE__*/React.createElement("footer", {
    className: "ftr"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ftr-top"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Logo, {
    theme: "dark",
    height: 26
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '20px 0 0',
      maxWidth: 340,
      lineHeight: 1.55
    }
  }, "Automa\xE7\xE3o, CRM, intelig\xEAncia artificial e software sob medida para empresas que querem operar com mais clareza."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 24
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "linkedin",
    label: "LinkedIn de Ian Amaral",
    tone: "dark",
    href: LINKEDIN_URL
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h5", null, "Navega\xE7\xE3o"), /*#__PURE__*/React.createElement("ul", null, /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "#solucoes"
  }, "Solu\xE7\xF5es")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "#processo"
  }, "Como trabalhamos")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "#sobre"
  }, "Sobre")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "#contato"
  }, "Contato")))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h5", null, "Parceria"), /*#__PURE__*/React.createElement("ul", null, /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: PARTNER_URL
  }, "Perfil DataCrazy \u2197")), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    href: "#datacrazy"
  }, "Implanta\xE7\xE3o de CRM"))))), /*#__PURE__*/React.createElement("div", {
    className: "ftr-bot"
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 DataDash Solutions"), /*#__PURE__*/React.createElement("span", null, "Parceiro homologado DataCrazy"))));
}
window.Footer = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Founder.jsx
try { (() => {
function Founder() {
  const {
    Button,
    Icon,
    Badge
  } = DS;
  return /*#__PURE__*/React.createElement("section", {
    className: "sec",
    id: "sobre",
    style: {
      background: 'var(--white)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap founder"
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement("div", {
    className: "photo"
  }, /*#__PURE__*/React.createElement("image-slot", {
    id: "founder-photo",
    shape: "rect",
    placeholder: "Foto de Ian Amaral \u2014 arraste o retrato aqui",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%'
    }
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Reveal, {
    className: "eyebrow"
  }, "06 \u2014 Sobre"), /*#__PURE__*/React.createElement(Reveal, {
    delay: 60
  }, /*#__PURE__*/React.createElement("h2", {
    className: "h2",
    style: {
      marginTop: 28
    }
  }, "Ian Amaral"), /*#__PURE__*/React.createElement("p", {
    className: "mono",
    style: {
      margin: '12px 0 0',
      fontSize: 12.5,
      color: 'var(--text-muted)'
    }
  }, "Ian Felipe Amaral Oliveira Silva \xB7 Fundador da DataDash Solutions")), /*#__PURE__*/React.createElement(Reveal, {
    delay: 120
  }, /*#__PURE__*/React.createElement("p", {
    className: "lead",
    style: {
      marginTop: 28
    }
  }, "Ian Amaral \xE9 desenvolvedor Full Stack e fundador da DataDash Solutions. Atua com automa\xE7\xE3o de processos, integra\xE7\xF5es, an\xE1lise de dados e desenvolvimento de software sob medida, ajudando empresas a ganhar efici\xEAncia operacional e melhorar suas opera\xE7\xF5es de atendimento e vendas."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '16px 0 0',
      fontSize: 16.5,
      maxWidth: 600
    }
  }, "Como parceiro homologado DataCrazy, tamb\xE9m trabalha na implanta\xE7\xE3o e personaliza\xE7\xE3o de CRM."), /*#__PURE__*/React.createElement("div", {
    className: "hero-ctas"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconLeft: "linkedin",
    href: LINKEDIN_URL
  }, "LinkedIn"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    iconRight: "arrow-up-right",
    href: PARTNER_URL
  }, "Perfil de parceiro DataCrazy"))))));
}
window.Founder = Founder;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Founder.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
function Header() {
  const {
    Logo,
    Button,
    IconButton
  } = DS;
  const [sc, setSc] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  React.useEffect(() => {
    const f = () => setSc(window.scrollY > 24);
    f();
    window.addEventListener('scroll', f, {
      passive: true
    });
    return () => window.removeEventListener('scroll', f);
  }, []);
  React.useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
  }, [open]);
  const links = [['Soluções', '#solucoes'], ['Como trabalhamos', '#processo'], ['Sobre', '#sobre'], ['Contato', '#contato']];
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("header", {
    className: 'hdr' + (sc ? ' scrolled' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap hdr-in"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    "aria-label": "DataDash \u2014 in\xEDcio",
    style: {
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    theme: "dark",
    height: 24
  })), /*#__PURE__*/React.createElement("nav", {
    className: "nav"
  }, links.map(([l, h]) => /*#__PURE__*/React.createElement("a", {
    key: h,
    href: h
  }, l))), /*#__PURE__*/React.createElement("div", {
    className: "hdr-cta"
  }, /*#__PURE__*/React.createElement("span", {
    className: "hide-m"
  }, /*#__PURE__*/React.createElement(Button, {
    size: "s",
    href: "#contato",
    iconRight: "arrow-right"
  }, "Iniciar conversa")), /*#__PURE__*/React.createElement("span", {
    className: "only-m"
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "menu",
    label: "Abrir menu",
    tone: "dark",
    onClick: () => setOpen(true)
  }))))), open && /*#__PURE__*/React.createElement("div", {
    className: "mnav",
    role: "dialog",
    "aria-label": "Menu"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hdr-in"
  }, /*#__PURE__*/React.createElement(Logo, {
    theme: "dark",
    height: 24
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "x",
    label: "Fechar menu",
    tone: "dark",
    onClick: () => setOpen(false)
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24,
      display: 'flex',
      flexDirection: 'column'
    }
  }, links.map(([l, h]) => /*#__PURE__*/React.createElement("a", {
    className: "big",
    key: h,
    href: h,
    onClick: () => setOpen(false)
  }, l))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "l",
    fullWidth: true,
    href: "#contato",
    onClick: () => setOpen(false),
    iconRight: "arrow-right"
  }, "Conversar sobre meu projeto"))));
}
window.Header = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
function Hero() {
  const {
    Button,
    Badge
  } = DS;
  return /*#__PURE__*/React.createElement("section", {
    id: "top",
    className: "dark hero",
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gridbg"
  }), /*#__PURE__*/React.createElement("div", {
    className: "glow"
  }), /*#__PURE__*/React.createElement("div", {
    className: "wrap",
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Reveal, null, /*#__PURE__*/React.createElement("a", {
    href: "#datacrazy",
    style: {
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "outline",
    tone: "dark",
    icon: "badge-check",
    style: {
      height: 32,
      padding: '0 14px',
      color: '#fff'
    }
  }, "Parceiro homologado DataCrazy"))), /*#__PURE__*/React.createElement("div", {
    className: "hero-top",
    style: {
      marginTop: 28
    }
  }, /*#__PURE__*/React.createElement(Reveal, {
    delay: 80
  }, /*#__PURE__*/React.createElement("h1", {
    className: "h-display"
  }, "Conecte seus processos. ", /*#__PURE__*/React.createElement("span", {
    className: "muted"
  }, "Simplifique sua opera\xE7\xE3o."))), /*#__PURE__*/React.createElement(Reveal, {
    delay: 180
  }, /*#__PURE__*/React.createElement("p", {
    className: "lead"
  }, "Automa\xE7\xE3o, CRM, intelig\xEAncia artificial e software sob medida para organizar o atendimento, reduzir tarefas manuais e transformar dados em decis\xF5es."), /*#__PURE__*/React.createElement("div", {
    className: "hero-ctas"
  }, /*#__PURE__*/React.createElement(Button, {
    size: "l",
    href: "#contato",
    iconRight: "arrow-right"
  }, "Conversar sobre meu projeto"), /*#__PURE__*/React.createElement(Button, {
    size: "l",
    variant: "secondary",
    tone: "dark",
    href: "#solucoes"
  }, "Conhecer as solu\xE7\xF5es")))), /*#__PURE__*/React.createElement(Reveal, {
    delay: 300
  }, /*#__PURE__*/React.createElement(FlowDemo, null))));
}
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Partner.jsx
try { (() => {
function Partner() {
  const {
    Button,
    Icon,
    Logo
  } = DS;
  const items = [['settings-2', 'Implantação', 'Configuração da conta, usuários, permissões e canais de atendimento.'], ['filter', 'Funis', 'Etapas desenhadas a partir do processo comercial real da empresa.'], ['workflow', 'Automações', 'Mensagens, tarefas e mudanças de etapa disparadas automaticamente.'], ['plug', 'Integrações', 'Conexão do CRM com site, formulários, ERP e outras ferramentas.'], ['users-round', 'Organização da operação', 'Regras de distribuição, rotina da equipe e acompanhamento de atendimento e vendas.']];
  return /*#__PURE__*/React.createElement("section", {
    className: "sec partner",
    id: "datacrazy"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap partner-grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Reveal, {
    className: "eyebrow"
  }, "03 \u2014 Parceria"), /*#__PURE__*/React.createElement(Reveal, {
    delay: 60
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      margin: '28px 0 24px'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    variant: "symbol",
    theme: "white",
    height: 28
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: 28,
      background: 'rgba(255,255,255,.3)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '600 20px var(--font-sans)',
      color: '#fff',
      letterSpacing: '-.01em'
    }
  }, "DataCrazy")), /*#__PURE__*/React.createElement("h2", {
    className: "h2"
  }, "Parceiro homologado DataCrazy.")), /*#__PURE__*/React.createElement(Reveal, {
    delay: 120
  }, /*#__PURE__*/React.createElement("p", {
    className: "lead",
    style: {
      color: 'rgba(255,255,255,.82)',
      marginTop: 24
    }
  }, "Implantamos e personalizamos o CRM DataCrazy para que atendimento e vendas funcionem no mesmo lugar, do primeiro contato no WhatsApp ao fechamento."), /*#__PURE__*/React.createElement("div", {
    className: "hero-ctas"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "inverse",
    size: "l",
    href: PARTNER_URL,
    iconRight: "arrow-up-right"
  }, "Ver perfil oficial de parceiro"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    tone: "dark",
    size: "l",
    href: "#contato"
  }, "Conversar sobre implanta\xE7\xE3o")), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 32,
      fontSize: 13,
      color: 'rgba(255,255,255,.62)',
      maxWidth: 460
    }
  }, "A DataDash Solutions \xE9 uma empresa independente, parceira homologada da DataCrazy."))), /*#__PURE__*/React.createElement("div", {
    className: "p-list"
  }, items.map(([ic, t, d], k) => /*#__PURE__*/React.createElement(Reveal, {
    key: t,
    delay: k * 70,
    className: "p-item"
  }, /*#__PURE__*/React.createElement("b", null, /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    size: 18,
    color: "var(--indigo-200)"
  }), t), /*#__PURE__*/React.createElement("p", null, d))))));
}
window.Partner = Partner;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Partner.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Problems.jsx
try { (() => {
const PROBLEMS = [['Leads perdidos entre conversas e planilhas.', 'Cada conversa do WhatsApp vira um registro no CRM, com origem, responsável e próximo passo.'], ['Equipe ocupada copiando informações entre sistemas.', 'Integrações levam os dados de um sistema para o outro automaticamente, sem redigitação.'], ['Falta de acompanhamento comercial.', 'Funis com etapas claras, lembretes e tarefas criadas no momento certo.'], ['Ferramentas que não compartilham dados.', 'Conectores e APIs unem CRM, ERP, planilhas e plataformas de atendimento.'], ['Dificuldade para visualizar resultados e gargalos.', 'Dashboards com os indicadores que a gestão acompanha, atualizados sem montagem manual.']];
function Problems() {
  const {
    Icon
  } = DS;
  return /*#__PURE__*/React.createElement("section", {
    className: "sec",
    id: "problemas"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement(SecHead, {
    eyebrow: "01 \u2014 Problemas que resolvemos",
    title: "Onde a opera\xE7\xE3o perde tempo, e o que muda quando tudo se conecta.",
    lead: "Situa\xE7\xF5es comuns em empresas que cresceram mais r\xE1pido que seus processos. Cada uma tem uma melhoria concreta que pode ser implementada."
  }), /*#__PURE__*/React.createElement("div", {
    className: "prob-head"
  }, /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null, "Hoje"), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("span", null, "Com a DataDash")), /*#__PURE__*/React.createElement("div", {
    className: "prob"
  }, PROBLEMS.map(([p, s], k) => /*#__PURE__*/React.createElement(Reveal, {
    key: k,
    delay: k * 60,
    className: "prob-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "n"
  }, "0", k + 1), /*#__PURE__*/React.createElement("span", {
    className: "p"
  }, p), /*#__PURE__*/React.createElement("span", {
    className: "a"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "s"
  }, s))))));
}
window.Problems = Problems;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Problems.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Process.jsx
try { (() => {
function Process() {
  const r = React.useRef(null);
  const v = useInView(r, {
    threshold: .35
  });
  const steps = [['Entendimento', 'Conversamos sobre a operação, a equipe, as ferramentas atuais e os objetivos do negócio.'], ['Mapeamento', 'Identificamos gargalos, tarefas repetitivas e oportunidades de automação ou integração.'], ['Implementação', 'Definimos a solução mais adequada ao contexto e colocamos em funcionamento.'], ['Validação e evolução', 'Testamos com a equipe, orientamos o uso e evoluímos conforme o escopo contratado.']];
  return /*#__PURE__*/React.createElement("section", {
    className: "sec",
    id: "processo"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement(SecHead, {
    eyebrow: "04 \u2014 Como trabalhamos",
    title: "Um processo simples, do diagn\xF3stico \xE0 evolu\xE7\xE3o.",
    lead: "Cada etapa tem entregas claras. Voc\xEA sabe o que est\xE1 sendo feito, por que e o que vem a seguir."
  }), /*#__PURE__*/React.createElement("div", {
    ref: r,
    className: 'proc' + (v ? ' in' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "proc-line"
  }, /*#__PURE__*/React.createElement("i", null)), steps.map(([t, d], k) => /*#__PURE__*/React.createElement("div", {
    key: k,
    className: "proc-s"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot",
    style: {
      transitionDelay: k * 380 + 'ms'
    }
  }, "0", k + 1), /*#__PURE__*/React.createElement("h3", null, t), /*#__PURE__*/React.createElement("p", null, d))))));
}
window.Process = Process;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Process.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Solutions.jsx
try { (() => {
function Api() {
  const {
    Tooltip
  } = DS;
  return /*#__PURE__*/React.createElement(Tooltip, {
    content: "Interface que permite dois sistemas trocarem dados"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      borderBottom: '1px dotted var(--text-muted)',
      cursor: 'help'
    }
  }, "API"));
}
const SOLUTIONS = [{
  id: 'crm',
  icon: 'square-kanban',
  title: 'CRM e atendimento',
  problem: 'Contatos chegam por vários canais e o histórico se perde entre pessoas, aparelhos e planilhas.',
  do: ['Implantação e personalização de CRM, com destaque para o DataCrazy', 'Funis de venda e etapas de atendimento', 'Atendimento e vendas pelo WhatsApp centralizados', 'Distribuição de contatos e regras de responsáveis'],
  gain: 'Toda oportunidade tem dono, etapa e histórico. A gestão acompanha o funil inteiro.'
}, {
  id: 'auto',
  icon: 'workflow',
  title: 'Automações e integrações',
  problem: 'Tarefas repetitivas consomem horas da equipe e dependem de alguém lembrar de fazê-las.',
  do: ['Automação de processos e rotinas', /*#__PURE__*/React.createElement(React.Fragment, null, "Integra\xE7\xE3o entre ferramentas via ", /*#__PURE__*/React.createElement(Api, null), " e webhooks"), 'Sincronização entre CRM, ERP, planilhas e formulários', 'Notificações e tarefas disparadas por eventos'],
  gain: 'Menos trabalho manual, menos erros de digitação e processos que seguem o mesmo padrão.'
}, {
  id: 'ia',
  icon: 'bot',
  title: 'Agentes de IA',
  problem: 'Dúvidas frequentes, triagem e qualificação ocupam a equipe com conversas que seguem um padrão.',
  do: ['Agentes para triagem e qualificação de contatos', 'Respostas baseadas nas informações da empresa', 'Encaminhamento para uma pessoa quando necessário', 'IA aplicada onde ela resolve melhor que uma regra simples'],
  gain: 'Atendimento inicial mais rápido, com a equipe dedicada às conversas que exigem atenção humana.'
}, {
  id: 'dados',
  icon: 'chart-column',
  title: 'Dados e dashboards',
  problem: 'Os números existem, mas estão espalhados e chegam tarde para orientar decisões.',
  do: ['Definição dos indicadores de cada área', 'Dashboards conectados às fontes de dados', 'Tratamento e organização das bases', 'Relatórios recorrentes automatizados'],
  gain: 'Clareza sobre vendas, atendimento e gargalos, com dados atualizados.'
}, {
  id: 'soft',
  icon: 'code-xml',
  title: 'Software sob medida',
  problem: 'O processo da empresa é específico e as ferramentas prontas não se adaptam a ele.',
  do: ['Sistemas web e painéis internos', 'Portais e aplicações para clientes ou equipes', /*#__PURE__*/React.createElement(React.Fragment, null, "Servi\xE7os de backend e ", /*#__PURE__*/React.createElement(Api, null), "s"), 'Evolução conforme o escopo contratado'],
  gain: 'Uma ferramenta feita para o seu fluxo, integrada ao que você já usa.'
}];
function Solutions() {
  const {
    Icon,
    Tabs,
    Button
  } = DS;
  const [cur, setCur] = React.useState('crm');
  const s = SOLUTIONS.find(x => x.id === cur);
  const idx = SOLUTIONS.indexOf(s);
  return /*#__PURE__*/React.createElement("section", {
    className: "sec",
    id: "solucoes",
    style: {
      background: 'var(--paper-2)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wrap"
  }, /*#__PURE__*/React.createElement(SecHead, {
    eyebrow: "02 \u2014 Solu\xE7\xF5es",
    title: "Come\xE7amos pelo problema. A ferramenta vem depois.",
    lead: "Automa\xE7\xE3o convencional, intelig\xEAncia artificial ou software pr\xF3prio: a escolha depende do processo e do contexto de cada empresa. Estas s\xE3o as frentes em que atuamos."
  }), /*#__PURE__*/React.createElement("div", {
    className: "sol-tabs"
  }, /*#__PURE__*/React.createElement(Tabs, {
    items: SOLUTIONS.map(x => ({
      id: x.id,
      label: x.title
    })),
    value: cur,
    onChange: setCur,
    style: {
      flexWrap: 'nowrap'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "sol"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sol-list",
    role: "tablist"
  }, SOLUTIONS.map((x, k) => /*#__PURE__*/React.createElement("button", {
    key: x.id,
    role: "tab",
    "aria-selected": x.id === cur,
    className: 'sol-item' + (x.id === cur ? ' on' : ''),
    onClick: () => setCur(x.id)
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "0", k + 1), x.title))), /*#__PURE__*/React.createElement("div", {
    className: "sol-panel",
    key: cur,
    style: {
      animation: 'dd-rise .5s var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--indigo-50)',
      color: 'var(--indigo-700)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: s.icon,
    size: 26
  })), /*#__PURE__*/React.createElement("span", {
    className: "mono",
    style: {
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, "0", idx + 1, " / 05")), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '28px 0 0',
      font: '400 clamp(28px,3vw,40px)/1.08 var(--font-display)',
      letterSpacing: '-.025em',
      color: 'var(--text-strong)'
    }
  }, s.title), /*#__PURE__*/React.createElement("div", {
    className: "sol-cols"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", null, "O problema"), /*#__PURE__*/React.createElement("p", null, s.problem)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", null, "Como atuamos"), /*#__PURE__*/React.createElement("ul", null, s.do.map((d, k) => /*#__PURE__*/React.createElement("li", {
    key: k
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--indigo-700)',
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 16,
    strokeWidth: 2
  })), /*#__PURE__*/React.createElement("span", null, d))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", null, "O que muda"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-strong)',
      fontSize: 17,
      lineHeight: 1.45
    }
  }, s.gain))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 32,
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "s",
    href: "#contato",
    iconRight: "arrow-right"
  }, "Falar sobre ", s.title.toLowerCase()))))));
}
window.Solutions = Solutions;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Solutions.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/boot.js
try { (() => {
// Loads the compiled DS bundle; if it isn't built yet, compiles component sources in-browser. Then loads the kit's JSX in order and mounts.
(function () {
  var NS = 'DataDashDesignSystem_9ac7b0',
    ROOT = '../../';
  var SRC = ['core/Icon', 'core/Button', 'core/IconButton', 'core/Badge', 'core/Card', 'core/Logo', 'forms/Field', 'forms/Input', 'forms/Textarea', 'forms/Select', 'forms/Checkbox', 'navigation/Tabs', 'feedback/Toast', 'feedback/Tooltip'];
  function tx(code) {
    return Babel.transform(code, {
      presets: ['react']
    }).code;
  }
  function run(code) {
    var s = document.createElement('script');
    s.text = code;
    document.head.appendChild(s);
  }
  function fallback() {
    return Promise.all(SRC.map(function (p) {
      return fetch(ROOT + 'components/' + p + '.jsx').then(function (r) {
        return r.text();
      });
    })).then(function (list) {
      var names = [];
      var body = list.map(function (c) {
        c = c.replace(/^import .*$/mg, '');
        c = c.replace(/export function (\w+)/g, function (_, n) {
          names.push(n);
          return 'function ' + n;
        });
        return c;
      }).join('\n');
      run('(function(){' + tx(body) + '\nwindow.' + NS + '={' + names.join(',') + '};})();');
    });
  }
  function bundle() {
    return new Promise(function (res) {
      var s = document.createElement('script');
      s.src = ROOT + '_ds_bundle.js';
      s.onload = function () {
        res(!!window[NS]);
      };
      s.onerror = function () {
        res(false);
      };
      document.head.appendChild(s);
    });
  }
  window.ddBoot = function (files) {
    bundle().then(function (ok) {
      return ok ? null : fallback();
    }).then(function () {
      return Promise.all(files.map(function (f) {
        return fetch(f).then(function (r) {
          return r.text();
        });
      }));
    }).then(function (codes) {
      codes.forEach(function (c) {
        run(tx(c));
      });
    }).catch(function (e) {
      console.error('boot failed', e);
    });
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/boot.js", error: String((e && e.message) || e) }); }

// ui_kits/website/image-slot.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <image-slot> — user-fillable image placeholder.
 *
 * Drop this into a deck, mockup, or page wherever a design needs an image.
 * You control the slot's shape; it sizes to its container by default. When the search_stock_photos tool
 * is available, prefill the slot by default — write the photo's URL into
 * src (with credit/credit-href); the user can still fill or replace it
 * by dragging an image file onto it (or clicking to browse). The dropped
 * image persists across reloads via a .image-slots.state.json sidecar —
 * same read-via-fetch / write-via-window.omelette pattern as
 * design_canvas.jsx, so the filled slot shows on share links, downloaded
 * zips, and PPTX export. Outside the omelette runtime the slot is read-only.
 *
 * The sidecar is a SIBLING of the HTML file that uses this component: the
 * read is a document-relative fetch, and the host resolves the bridge's
 * sidecar writes into the previewed file's directory to match (same
 * contract as design_canvas.jsx). Pages in the same directory share one
 * sidecar; keep slot ids distinct across them.
 *
 * Attributes:
 *   id           Persistence key. REQUIRED for the drop to survive reload —
 *                every slot on the page needs a distinct id.
 *   shape        'rect' | 'rounded' | 'circle' | 'pill'   (default 'rounded')
 *                'circle' applies 50% border-radius; on a non-square slot
 *                that's an ellipse — set equal width and height for a true
 *                circle.
 *   radius       Corner radius in px for 'rounded'.       (default 12)
 *   mask         Any CSS clip-path value. Overrides `shape` — use this for
 *                hexagons, blobs, arbitrary polygons.
 *   fit          Initial framing baseline: cover | contain.   (default 'cover')
 *                cover starts the image filling the frame (overflow cropped);
 *                contain starts it fully visible (letterboxed). Either way the
 *                user can always pan/scale from there — double-click, or the
 *                Edit control, enters reframe mode (drag to move, scroll or
 *                corner-handles to scale; Escape / click-out commits). The
 *                crop persists alongside the image in the sidecar.
 *   placeholder  Empty-state caption.                      (default 'Drop an image')
 *   src          Optional initial/fallback image URL. Prefill it with a real
 *                photo via search_stock_photos when that tool is available
 *                (set credit/credit-href from the result). A user drop
 *                overrides it; clearing the drop reveals src again.
 *   credit       Attribution text shown as a small overlay at the
 *                bottom-left of the filled slot. REQUIRED whenever src
 *                points at any Unsplash host (images.unsplash.com,
 *                plus.unsplash.com, …): an Unsplash src with no credit
 *                renders an error tile INSTEAD of the photo (Unsplash
 *                terms forbid showing their photos unattributed). Use the
 *                exact form 'Photo by {photographer name} on Unsplash' —
 *                the overlay then links the name to credit-href and
 *                'Unsplash' to the Unsplash homepage, and links back to
 *                unsplash.com automatically get the required utm referral
 *                params appended at render time. The credit belongs to
 *                the src image, so it only shows while src is what's
 *                displayed — a user-dropped image hides it.
 *   credit-href  Link for the photographer's name in the credit overlay
 *                (their Unsplash profile URL from the stock-photo search
 *                results). http(s) URLs only — anything else renders the
 *                name as plain text.
 *
 * Sizing: the slot fills its container by default (width/height 100%).
 * Put it in a sized wrapper — absolutely positioned, a grid cell, a fixed
 * frame — and it takes exactly that box. When the parent's height is
 * indefinite (ordinary flow), it falls back to full width at a 3:2 aspect
 * ratio instead of collapsing. In a shrink-to-fit parent (a float,
 * width:max-content, an unsized absolute wrapper), percentages have
 * nothing to resolve against — size the slot or its wrapper explicitly
 * there. For a fixed-size slot, set
 * width/height on the element itself (inline style), which overrides the
 * default. When
 * layering content above a slot (full-bleed layouts), make the overlay
 * click-through — pointer-events: none on scrims/text plates, re-enabled
 * on interactive children — so the slot's hover controls stay reachable.
 * Keep the slot's bottom-left corner visually clear as well: the credit
 * overlay renders there, and a dark fade or text plate covering it hides
 * the attribution Unsplash's terms require — end the fade above that
 * corner, or keep it nearly transparent where the credit sits.
 *
 * Usage:
 *   <div style="position:relative;width:100%;height:100%">      <!-- full-bleed: -->
 *     <image-slot id="bg" shape="rect"></image-slot>            <!-- fills the wrapper -->
 *   </div>
 *   <image-slot id="hero"   style="width:800px;height:450px" shape="rounded" radius="20"
 *               placeholder="Drop a hero image"></image-slot>
 *   <image-slot id="avatar" style="width:120px;height:120px" shape="circle"></image-slot>
 *   <image-slot id="kite"   style="width:300px;height:300px"
 *               mask="polygon(50% 0, 100% 50%, 50% 100%, 0 50%)"></image-slot>
 */
/* END USAGE */

(() => {
  const STATE_FILE = '.image-slots.state.json';

  // Unsplash terms require visible attribution wherever their photos
  // display, and every link back to unsplash.com must carry utm referral
  // params. Two render-time rules enforce that here:
  //  - an Unsplash-src slot with NO credit attribute renders an error
  //    tile INSTEAD of the photo (an uncredited Unsplash photo on screen
  //    is itself the terms violation, so it never renders bare);
  //  - rendered credit links pointing at unsplash.com get the referral
  //    params appended when absent (credit-href values live in page
  //    content that can't be edited after the fact).
  // Keep the utm_source value in sync with UTM_SOURCE in
  // platform/web-agent/unsplash.ts — this file is a project-local
  // artifact and cannot import it (equality is pinned by tests).
  const UNSPLASH_HOMEPAGE_HREF = 'https://unsplash.com/?utm_source=claude_design&utm_medium=referral';
  // Host rule mirrors the hotlink validator that admits Unsplash srcs into
  // pages in the first place (cdn$ in unsplash.ts: apex or any subdomain)
  // — Unsplash+ results serve from plus.unsplash.com, not just images.*,
  // and an admitted-but-uncredited photo must error whatever unsplash
  // host it rides on.
  // Trailing-dot FQDNs (images.unsplash.com.) are the same host to the
  // browser but would miss the regex — strip one dot so the check fails
  // CLOSED (unrecognized-but-real Unsplash srcs must error, not render).
  const isUnsplashHost = u => {
    try {
      return /(^|\.)unsplash\.com$/.test(new URL(u, document.baseURI).hostname.replace(/\.$/, ''));
    } catch {
      return false;
    }
  };
  // Render-time referral normalization for links back to Unsplash:
  // appends utm_source/utm_medium when absent, preserves every existing
  // query param, never overwrites an existing utm_source, and passes
  // non-Unsplash URLs through untouched. Input is an ABSOLUTE validated
  // http(s) URL (the credit render funnel resolves + validates first).
  const withReferral = href => {
    try {
      const u = new URL(href);
      if (!/(^|\.)unsplash\.com$/.test(u.hostname.replace(/\.$/, ''))) {
        return href;
      }
      if (!u.searchParams.has('utm_source')) {
        u.searchParams.set('utm_source', 'claude_design');
      }
      if (!u.searchParams.has('utm_medium')) {
        u.searchParams.set('utm_medium', 'referral');
      }
      return u.toString();
    } catch (e) {
      return href;
    }
  };
  // 2× a ~600px slot in a 1920-wide deck — retina-sharp without making the
  // sidecar enormous. A 1200px WebP at q=0.85 is ~150-300KB.
  const MAX_DIM = 1200;
  // Raster formats only. SVG is excluded (can carry script; createImageBitmap
  // on SVG blobs is inconsistent). GIF is excluded because the canvas
  // re-encode keeps only the first frame, so an animated GIF would silently
  // go still — better to reject than surprise.
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];

  // ── Shared sidecar store ────────────────────────────────────────────────
  // One fetch + immediate write-on-change for every <image-slot> on the
  // page. Reads via fetch() so viewing works anywhere the HTML and sidecar
  // are served together; writes go through window.omelette.writeFile, which
  // the host allowlists to *.state.json basenames only.
  const subs = new Set();
  let slots = {};
  // ids explicitly cleared before the sidecar fetch resolved — otherwise
  // the merge below can't tell "never set" from "just deleted" and would
  // resurrect the sidecar's stale value.
  const tombstones = new Set();
  let loaded = false;
  let loadP = null;
  function load() {
    if (loadP) return loadP;
    loadP = fetch(STATE_FILE).then(r => r.ok ? r.json() : null).then(j => {
      // Merge: sidecar loses to any in-memory change that raced ahead of
      // the fetch (drop or clear) so neither is clobbered by hydration.
      if (j && typeof j === 'object') {
        const merged = Object.assign({}, j, slots);
        // A framing-only write that raced ahead of hydration must not
        // drop a user image that's only on disk — inherit u from the
        // sidecar for any in-memory entry that lacks one.
        for (const k in slots) {
          if (merged[k] && !merged[k].u && j[k]) {
            merged[k].u = typeof j[k] === 'string' ? j[k] : j[k].u;
          }
        }
        for (const id of tombstones) delete merged[id];
        slots = merged;
      }
      tombstones.clear();
    }).catch(() => {}).then(() => {
      loaded = true;
      subs.forEach(fn => fn());
    });
    return loadP;
  }

  // Serialize writes so two near-simultaneous drops on different slots
  // can't reorder at the backend and leave the sidecar with only the
  // first. A save requested mid-flight just marks dirty and re-fires on
  // completion with the then-current slots.
  let saving = false;
  let saveDirty = false;
  // Unload-time flush: save()'s serialization defers a mid-RTT re-fire to a
  // .then that never runs in an unloading document, silently dropping a
  // pagehide commit. Post the current slots immediately instead — content
  // is a superset snapshot of any in-flight save's, the write is a
  // whole-file last-writer-wins replace, and postMessage FIFO delivers it
  // to the host after the in-flight one, so a backend-side reorder at
  // worst reproduces the dropped-commit outcome this flush improves on.
  // Guarded on the initial sidecar read: pre-hydration slots can miss
  // other slots' persisted entries, and flushing it would clobber them —
  // that narrow case stays best-effort (the in-memory merge in load()
  // cannot happen in an unloading document anyway).
  function flushNow() {
    if (!loaded) return;
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    try {
      Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {});
    } catch (e) {}
  }
  function save() {
    if (saving) {
      saveDirty = true;
      return;
    }
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    saving = true;
    Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {}).then(() => {
      saving = false;
      if (saveDirty) {
        saveDirty = false;
        save();
      }
    });
  }
  const S_MAX = 5;
  const clampS = s => Math.max(1, Math.min(S_MAX, s));

  // Normalize a stored slot value. Pre-reframe sidecars stored a bare
  // data-URL string; newer ones store {u, s, x, y}. Either shape is valid.
  function getSlot(id) {
    const v = slots[id];
    if (!v) return null;
    return typeof v === 'string' ? {
      u: v,
      s: 1,
      x: 0,
      y: 0
    } : v;
  }
  function setSlot(id, val) {
    if (!id) return;
    if (val) {
      slots[id] = val;
      tombstones.delete(id);
    } else {
      delete slots[id];
      if (!loaded) tombstones.add(id);
    }
    subs.forEach(fn => fn());
    // A drop is rare + high-value — write immediately so nav-away can't lose
    // it. Gate on the initial read so we don't overwrite a sidecar we haven't
    // merged yet; the merge in load() keeps this change once the read lands.
    if (loaded) save();else load().then(save);
  }

  // ── Image downscale ─────────────────────────────────────────────────────
  // Encode through a canvas so the sidecar carries resized bytes, not the
  // raw upload. Longest side is capped at 2× the slot's rendered width
  // (retina) and at MAX_DIM. WebP keeps alpha and is ~10× smaller than PNG
  // for photos, so there's no need for per-image format picking.
  async function toDataUrl(file, targetW) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.max(1, Math.round(targetW * 2)) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      bitmap.close && bitmap.close();
    }
  }

  // ── Custom element ──────────────────────────────────────────────────────
  const stylesheet =
  // Fill the container by default: slots are usually placed inside a
  // sized wrapper (a hero frame, a grid cell, an inset:0 layer) and are
  // expected to take that box — a fixed intrinsic size would render as
  // a small tile in the corner of a full-bleed wrapper instead.
  // aspect-ratio is the companion fallback that keeps a bare slot
  // visible when the parent's height is indefinite: height:100%
  // resolves to auto there, and the ratio then derives height from
  // width instead of letting the slot collapse to zero height.
  // Explicit width/height on the element override all of this.
  // color:inherit (not a fixed near-black): the placeholder chrome —
  // empty-state icon/caption (currentColor) and the dashed ring — must
  // read on dark decks too, and the slide's own text color is the one
  // color guaranteed to contrast with the slide background. The soft
  // look comes from opacity on those parts, not from a baked-in alpha.
  ':host{display:block;position:relative;' + '  font:13px/1.3 system-ui,-apple-system,sans-serif;' + '  width:100%;height:100%;aspect-ratio:3/2}' + '.empty .cap,.empty .sub{opacity:.75}' + '.frame{position:absolute;inset:0;overflow:hidden;background:rgba(127,127,127,.08)}' +
  // .frame img (clipped) and .spill (unclipped ghost + handles) share the
  // same left/top/width/height in frame-%, computed by _applyView(), so the
  // inside-mask crop and the outside-mask spill stay pixel-aligned.
  '.frame img{position:absolute;max-width:none;transform:translate(-50%,-50%);' + '  -webkit-user-drag:none;user-select:none;touch-action:none}' +
  // Reframe mode (double-click): the full image spills past the mask. The
  // spill layer is sized to the IMAGE bounds so its corners are where the
  // resize handles belong. The ghost <img> inside is translucent; the real
  // clipped <img> underneath shows the opaque in-mask crop.
  // popover=manual promotes the spill to the top layer on reframe, so it is
  // not clipped by any overflow:hidden / clip-path / scroll-container
  // ancestor (a plain z-index can't escape overflow clipping). UA popover
  // defaults (inset:0;margin:auto) are reset; _applyView sets viewport px.
  '.spill{position:fixed;margin:0;inset:auto;border:0;padding:0;background:transparent;' + '  overflow:visible;transform:translate(-50%,-50%);z-index:1;cursor:grab;touch-action:none}' + ':host([data-panning]) .spill{cursor:grabbing}' + '.spill .ghost{position:absolute;inset:0;width:100%;height:100%;opacity:.35;' + '  pointer-events:none;-webkit-user-drag:none;user-select:none;' + '  box-shadow:0 0 0 1px rgba(0,0,0,.2),0 12px 32px rgba(0,0,0,.2)}' + '.spill .handle{position:absolute;width:12px;height:12px;border-radius:50%;' + '  background:#fff;box-shadow:0 0 0 1.5px #c96442,0 1px 3px rgba(0,0,0,.3);' + '  transform:translate(-50%,-50%)}' + '.spill .handle[data-c=nw]{left:0;top:0;cursor:nwse-resize}' + '.spill .handle[data-c=ne]{left:100%;top:0;cursor:nesw-resize}' + '.spill .handle[data-c=sw]{left:0;top:100%;cursor:nesw-resize}' + '.spill .handle[data-c=se]{left:100%;top:100%;cursor:nwse-resize}' + ':host([data-reframe]){z-index:10}' + ':host([data-reframe]) .frame{box-shadow:0 0 0 2px #c96442}' + '.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  cursor:pointer;user-select:none}' + '.empty svg{opacity:.45}' + '.empty .cap{max-width:90%;font-weight:500;letter-spacing:.01em}' + '.empty .sub{font-size:11px}' + '.empty .sub u{text-underline-offset:2px}' + '.empty:hover .sub{opacity:1}' + ':host([data-over]) .frame{outline:2px solid #c96442;outline-offset:-2px;' + '  background:rgba(201,100,66,.10)}' + '.ring{position:absolute;inset:0;pointer-events:none;border:1.5px dashed currentColor;' + '  opacity:.35;transition:border-color .12s,opacity .12s}' + ':host([data-over]) .ring{border-color:#c96442;opacity:1}' + ':host([data-filled]) .ring{display:none}' +
  // Controls overlay INSIDE the frame, pinned to the top-right corner, so
  // a full-bleed slot in an overflow:hidden container still shows them
  // (the old below-mask placement got clipped). Credit sits bottom-left,
  // so top-right avoids collision. The blurred pill background keeps them
  // legible over the image.
  // The UA [popover] base rule styles the element in EVERY state (only
  // display:none is gated on :not(:popover-open), and the display:flex
  // below overrides that) — so the UA resets live HERE, like .spill's,
  // or the ordinary hover-state strip renders as a bordered Canvas box
  // centered by margin:auto. inset:auto precedes top/right (shorthand).
  '.ctl{position:absolute;inset:auto;top:8px;right:8px;margin:0;border:0;padding:0;' + '  background:transparent;overflow:visible;' + '  display:flex;gap:6px;opacity:0;pointer-events:none;transition:opacity .12s;z-index:2;' + '  white-space:nowrap}' +
  // While reframing, the spill owns the top layer and would swallow every
  // click on the in-frame controls. Promoting .ctl into the top layer
  // ABOVE the spill (shown after it — later popovers stack higher) keeps
  // Edit-as-toggle and Replace clickable mid-reframe. _applyView pins it
  // to the frame's top-right in viewport px (translateX(-100%)
  // right-aligns against the computed left edge); inset:auto clears the
  // base rule's top/right so the inline left/top position it alone.
  '.ctl:popover-open{position:fixed;inset:auto;transform:translateX(-100%)}' + ':host([data-filled][data-editable]:hover) .ctl,:host([data-reframe]) .ctl' + '  {opacity:1;pointer-events:auto}' + '.ctl button{appearance:none;border:0;border-radius:6px;padding:5px 10px;cursor:pointer;' + '  background:rgba(0,0,0,.65);color:#fff;font:11px/1 system-ui,-apple-system,sans-serif;' + '  backdrop-filter:blur(6px)}' + '.ctl button:hover{background:rgba(0,0,0,.8)}' + '.err{position:absolute;left:8px;bottom:8px;right:8px;color:#b3261e;font-size:11px;' + '  background:rgba(255,255,255,.85);padding:4px 6px;border-radius:5px;pointer-events:none}' +
  // Replacement in flight: after a src swap the browser keeps painting
  // the PREVIOUS image until the new one decodes, so a Replace would
  // flash the old photo and then pop. Hide the stale frame (visibility,
  // not display — _applyView geometry still applies) and spin until the
  // new image reports in (load/error clears data-swapping).
  ':host([data-swapping]) .frame img{visibility:hidden}' + '.loading{position:absolute;inset:0;display:none;align-items:center;' + '  justify-content:center;pointer-events:none}' + ':host([data-swapping]) .loading{display:flex}' + '.loading::after{content:"";width:22px;height:22px;border-radius:50%;' + '  border:2px solid rgba(127,127,127,.25);border-top-color:currentColor;' + '  animation:om-slot-spin .7s linear infinite}' + '@keyframes om-slot-spin{to{transform:rotate(360deg)}}' +
  // Reduced motion: the static two-tone ring still reads as "working".
  '@media (prefers-reduced-motion:reduce){.loading::after{animation:none}}' + '.credit{position:absolute;left:6px;bottom:6px;max-width:calc(100% - 12px);display:none;' + '  padding:3px 7px;border-radius:5px;background:rgba(0,0,0,.55);color:#fff;' + '  font:10px/1.2 system-ui,-apple-system,sans-serif;text-decoration:none;' + '  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;backdrop-filter:blur(6px)}' +
  // The credit is a SPAN holding one or two <a>s (Unsplash's prescribed
  // form links the photographer AND Unsplash) — anchors style inline so
  // the overlay reads as one line of text.
  '.credit a{color:inherit;text-decoration:none}' + '.credit a:hover,.credit a:focus-visible{text-decoration:underline}' + ':host([data-filled][data-credit]) .credit{display:block}' +
  // Exports must ship JUST the image — no hover controls, no credit chip
  // (the host marks <html data-om-exporting> for the capture window; the
  // page-level hide script can't reach shadow DOM, this rule can).
  ':host-context([data-om-exporting]) .ctl,' + ':host-context([data-om-exporting]) .credit{display:none !important}' +
  // Print must ship just the image too: the hover-gated controls can be
  // mid-hover when print() fires, and the credit chip is screen chrome —
  // the same rule the capture window gets, keyed on print media instead
  // of the host's data-om-exporting mark (the print path sets no mark).
  '@media print{.ctl,.credit{display:none !important}}' +
  // No export-window mask rules here on purpose: the export capture
  // releases the replacement mask by REMOVING data-swapping (the
  // shadow-root pass in pages/export/shared.ts HIDE_EXPORT_CHROME_SCRIPT)
  // — attribute removal works in every engine (:host-context is
  // Chromium-only), is scoped by construction to slots actually
  // mid-swap, and hides the spinner through the same gate. A masked img
  // would otherwise be silently dropped from PPTX decks (the capture
  // walk skips visibility:hidden imgs).
  // Attribution error tile: REPLACES the photo when an Unsplash src has
  // no credit attribute — rendering the photo uncredited is the terms
  // violation, so the photo must not appear at all.
  // Calm and neutral on purpose (review feedback): the tile informs the
  // user; the fix instructions are machine-facing (usage docblock, tool
  // description, and the turn-end scan's bounce copy name the attributes
  // for the agent).
  '.attr-error{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  background:#f2f1ef;color:#6e6c66;user-select:none;' + '  font:13px/1.45 system-ui,-apple-system,sans-serif}' + '.attr-error svg{opacity:.55}' + '.attr-error .cap{max-width:92%;font-weight:500;letter-spacing:.01em}' + ':host([data-attribution-error]) .attr-error{display:flex}' + ':host([data-attribution-error]) .ring{display:none}';
  const icon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' + '<path d="m21 15-5-5L5 21"/></svg>';
  const warnIcon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>' + '<path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
  class ImageSlot extends HTMLElement {
    static get observedAttributes() {
      return ['shape', 'radius', 'mask', 'fit', 'placeholder', 'src', 'id', 'credit', 'credit-href'];
    }

    /** Duplicate-slide hook (called by deck-stage, see its
     *  _remintDuplicateIds): copy this id's stored image, if any, under a
     *  freshly minted key and return that key — so a duplicated slide's
     *  slot keeps its dropped photo instead of reverting to the
     *  placeholder. 'isFree' is the caller's uniqueness check (document
     *  ids); candidates must ALSO be unused in the sidecar, which can
     *  hold keys from other pages sharing the project root. (An EMPTY
     *  slot on another page leaves no sidecar entry, so its id is not
     *  detectable here — a minted key can collide with it and that slot
     *  would show this photo. Same blast radius as two pages reusing an
     *  id by hand, which the shared sidecar already permits.) Returns null
     *  when no id could be minted (caller strips the id, today's
     *  behavior). */
    static cloneSlot(fromId, isFree) {
      if (typeof fromId !== 'string' || !fromId) return null;
      // Pre-hydration the store can't veto candidates or source the copy
      // — degrade to the strip (today's behavior) rather than mint
      // against keys we can't see yet. Any rendered (= droppable) slot
      // means load() has already settled.
      if (!loaded) return null;
      const stem = fromId.replace(/-\d+$/, '') || fromId;
      for (let n = 2; n < 100; n++) {
        const toId = stem + '-' + n;
        if (toId === fromId) continue;
        if (slots[toId] !== undefined) {
          // Reuse a key holding this exact value (bytes AND crop) if no
          // live element here owns it — a duplicate op the host refused
          // after minting leaves such a key behind, and reusing keeps
          // refused retries from accumulating one orphaned copy per
          // attempt. Full equality (not just bytes) so a byte-identical
          // key another PAGE owns with its own crop is stepped past, not
          // adopted or rewritten. (Entries without .u never match.)
          const prev = getSlot(toId);
          const cur = getSlot(fromId);
          if (!(prev && cur && prev.u && prev.u === cur.u && prev.s === cur.s && prev.x === cur.x && prev.y === cur.y && (typeof isFree !== 'function' || isFree(toId)))) continue;
          return toId;
        }
        if (typeof isFree === 'function' && !isFree(toId)) continue;
        const v = getSlot(fromId);
        if (v) setSlot(toId, Object.assign({}, v));
        return toId;
      }
      return null;
    }
    constructor() {
      super();
      // clonable: rail thumbnails deep-clone slides and carry this shadow
      // along; reuse an already-cloned root so upgrade-after-clone works.
      // (Deliberately NOT serializable — a getHTML consumer would embed
      // multi-MB sidecar data-URLs into serialized page HTML.)
      const root = this.shadowRoot || this.attachShadow({
        mode: 'open',
        clonable: true
      });
      // .spill and .ctl sit OUTSIDE .frame so overflow:hidden + border-radius
      // on the frame (circle, pill, rounded) can't clip them.
      root.innerHTML = '<style>' + stylesheet + '</style>' + '<div class="frame" part="frame">' + '  <img part="image" alt="" draggable="false" style="display:none">' + '  <div class="empty" part="empty">' + icon + '    <div class="cap"></div>' + '    <div class="sub">or <u>browse files</u></div></div>' + '  <div class="attr-error" part="attribution-error">' + warnIcon + '    <div class="cap">This photo needs attribution</div></div>' + '  <div class="loading" part="loading"></div>' + '  <div class="ring" part="ring"></div>' + '</div>' +
      // Outside .frame, like .spill/.ctl — the frame's overflow:hidden +
      // border-radius/clip-path would cut the credit off on circle/pill/mask.
      // A SPAN, not an <a>: the prescribed Unsplash credit holds two links
      // (photographer + Unsplash), built per-render in _render().
      '<span class="credit" part="credit"></span>' + '<div class="spill" popover="manual" data-dc-edit-transparent>' + '  <img class="ghost" alt="" draggable="false">' + '  <div class="handle" data-c="nw"></div><div class="handle" data-c="ne"></div>' + '  <div class="handle" data-c="sw"></div><div class="handle" data-c="se"></div>' + '</div>' +
      // data-dc-edit-transparent: the DC editor's edit-mode picker lets
      // clicks through for chrome marked with it (EDIT_TRANSPARENT_SEL)
      // — without it, Replace/Edit clicks in Edit mode are swallowed by
      // element selection and the controls look dead.
      '<div class="ctl" popover="manual" data-dc-edit-transparent><button data-act="replace" title="Replace image">Replace</button>' + '  <button data-act="edit" title="Reframe image">Edit</button></div>' + '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';
      this._frame = root.querySelector('.frame');
      this._ring = root.querySelector('.ring');
      this._img = root.querySelector('.frame img');
      this._empty = root.querySelector('.empty');
      this._cap = root.querySelector('.cap');
      this._sub = root.querySelector('.sub');
      this._spill = root.querySelector('.spill');
      this._ctl = root.querySelector('.ctl');
      this._credit = root.querySelector('.credit');
      this._attrError = root.querySelector('.attr-error');
      // Credit clicks open the link, not browse/reframe.
      this._credit.addEventListener('click', e => e.stopPropagation());
      this._credit.addEventListener('dblclick', e => e.stopPropagation());
      this._ghost = root.querySelector('.ghost');
      this._err = null;
      this._input = root.querySelector('input');
      this._depth = 0;
      this._gen = 0;
      // Encode-in-flight marker (the owning _ingest generation): while set,
      // the same-src "nothing in flight" clear in _render must not fire —
      // the stored value still points at the OLD image until the encode
      // lands, so that clear would unmask the stale image mid-replace.
      this._swapGen = 0;
      // Render-owned swap in flight: set when _render assigns a new src,
      // cleared only by the img's own load/error (or the empty branch).
      // img.complete CANNOT stand in for this — setting src only QUEUES
      // the current-request swap (a microtask), so synchronously after an
      // assignment, complete still reports the OLD settled request. The
      // pick path does exactly that: the host sets src, credit, and
      // credit-href back-to-back in one task, and renders #2/#3 would
      // read the stale complete === true and drop the mask one render
      // after it was set.
      this._loadPending = false;
      // See _render's empty branch: a transient attribution-error wipe of a
      // showing image must make the follow-up render a replacement (spinner),
      // not a first fill (blank frame).
      this._hidShowing = false;
      this._view = {
        s: 1,
        x: 0,
        y: 0
      };
      this._subFn = () => this._render();
      // Shadow-DOM listeners live with the shadow DOM — bound once here so
      // disconnect/reconnect (e.g. React remount) doesn't stack handlers.
      this._empty.addEventListener('click', () => this._input.click());
      root.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (!act) return;
        // The hidden controls are opacity-0 but still tabbable — without
        // this gate a keyboard user could drive them on a read-only share
        // link (mirrors the dblclick handler's editable gate).
        if (!this.hasAttribute('data-editable')) return;
        if (act === 'replace') {
          this._exitReframe(true);
          // Host-owned picker (Unsplash modal; it also offers local import).
          this.dispatchEvent(new CustomEvent('image-slot:pick', {
            bubbles: true,
            composed: true,
            detail: {
              id: this.id || null
            }
          }));
        }
        if (act === 'edit') {
          if (!this._reframes()) return;
          if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
        }
      });
      this._input.addEventListener('change', () => {
        const f = this._input.files && this._input.files[0];
        if (f) this._ingest(f);
        this._input.value = '';
      });
      // naturalWidth/Height aren't known until load — re-apply so the cover
      // baseline is computed from real dimensions, not the 100%×100% fallback.
      // load/error also release the replacement-in-flight mask (via the
      // single discipline in _releaseMask): the swap is only revealed once
      // the new image can actually paint (on error the frame shows its
      // background, same as a fresh slot with a broken src).
      this._img.addEventListener('load', () => {
        this._loadPending = false;
        this._releaseMask(true);
        this._applyView();
      });
      this._img.addEventListener('error', () => {
        this._loadPending = false;
        this._releaseMask(true);
      });
      // Gated only on editable — any filled slot can be repositioned/scaled,
      // regardless of fit. Share links (no writeFile) stay static.
      this.addEventListener('dblclick', e => {
        if (!this.hasAttribute('data-editable') || !this._reframes()) return;
        e.preventDefault();
        if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
      });
      // Pan + resize both originate on the spill layer. A handle pointerdown
      // drives an aspect-locked resize anchored at the opposite corner; any
      // other pointerdown on the spill pans. Offsets are frame-% so a
      // reframed slot survives responsive resize / PPTX export.
      this._spill.addEventListener('pointerdown', e => {
        if (e.button !== 0 || !this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        e.stopPropagation();
        this._spill.setPointerCapture(e.pointerId);
        const rect = this.getBoundingClientRect();
        const fw = rect.width || 1,
          fh = rect.height || 1;
        const corner = e.target.getAttribute && e.target.getAttribute('data-c');
        let move;
        if (corner) {
          // Resize about the OPPOSITE corner. Viewport-px throughout (rect
          // fw/fh, not clientWidth) so the math survives a transform:scale()
          // ancestor — deck_stage renders slides scaled-to-fit.
          const iw = this._img.naturalWidth || 1,
            ih = this._img.naturalHeight || 1;
          const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
          const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
          const sx = corner.includes('e') ? 1 : -1;
          const sy = corner.includes('s') ? 1 : -1;
          const s0 = this._view.s;
          const w0 = iw * base * s0,
            h0 = ih * base * s0;
          const cx0 = (50 + this._view.x) / 100 * fw;
          const cy0 = (50 + this._view.y) / 100 * fh;
          const ox = cx0 - sx * w0 / 2,
            oy = cy0 - sy * h0 / 2;
          const diag0 = Math.hypot(w0, h0);
          const ux = sx * w0 / diag0,
            uy = sy * h0 / diag0;
          move = ev => {
            const proj = (ev.clientX - rect.left - ox) * ux + (ev.clientY - rect.top - oy) * uy;
            const s = clampS(s0 * proj / diag0);
            const d = diag0 * s / s0;
            this._view.s = s;
            this._view.x = (ox + ux * d / 2) / fw * 100 - 50;
            this._view.y = (oy + uy * d / 2) / fh * 100 - 50;
            this._clampView();
            this._applyView();
          };
        } else {
          this.setAttribute('data-panning', '');
          const start = {
            px: e.clientX,
            py: e.clientY,
            x: this._view.x,
            y: this._view.y
          };
          move = ev => {
            this._view.x = start.x + (ev.clientX - start.px) / fw * 100;
            this._view.y = start.y + (ev.clientY - start.py) / fh * 100;
            this._clampView();
            this._applyView();
          };
        }
        const up = () => {
          try {
            this._spill.releasePointerCapture(e.pointerId);
          } catch {}
          this._spill.removeEventListener('pointermove', move);
          this._spill.removeEventListener('pointerup', up);
          this._spill.removeEventListener('pointercancel', up);
          this.removeAttribute('data-panning');
          this._dragUp = null;
        };
        // Stashed so _exitReframe (Escape / outside-click mid-drag) can
        // tear the capture + listeners down synchronously.
        this._dragUp = up;
        this._spill.addEventListener('pointermove', move);
        this._spill.addEventListener('pointerup', up);
        this._spill.addEventListener('pointercancel', up);
      });
      // Wheel zoom stays available inside reframe mode as a trackpad nicety —
      // zooms toward the cursor (offset' = cursor·(1-k) + offset·k).
      this.addEventListener('wheel', e => {
        if (!this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        const r = this.getBoundingClientRect();
        const cx = (e.clientX - r.left) / r.width * 100 - 50;
        const cy = (e.clientY - r.top) / r.height * 100 - 50;
        const prev = this._view.s;
        const next = clampS(prev * Math.pow(1.0015, -e.deltaY));
        if (next === prev) return;
        const k = next / prev;
        this._view.s = next;
        this._view.x = cx * (1 - k) + this._view.x * k;
        this._view.y = cy * (1 - k) + this._view.y * k;
        this._clampView();
        this._applyView();
      }, {
        passive: false
      });
    }
    connectedCallback() {
      // Warn once per page — an id-less slot works for the session but
      // cannot persist, and two id-less slots would share nothing.
      if (!this.id && !ImageSlot._warned) {
        ImageSlot._warned = true;
        console.warn('<image-slot> without an id will not persist its dropped image.');
      }
      this.addEventListener('dragenter', this);
      this.addEventListener('dragover', this);
      this.addEventListener('dragleave', this);
      this.addEventListener('drop', this);
      subs.add(this._subFn);
      // The host may inject window.omelette.writeFile AFTER the first render;
      // re-render on hover so the editable-gated controls reliably appear.
      this.addEventListener('pointerenter', this._subFn);
      // width%/height% in _applyView encode the frame aspect at call time —
      // a host resize (responsive grid, pane divider) would stretch the
      // image until the next _render. Re-render on size change: _render()
      // re-seeds _view from stored before clamp/apply, so a shrink→grow
      // cycle round-trips instead of ratcheting x/y toward the narrower
      // frame's clamp range.
      this._ro = new ResizeObserver(() => this._render());
      this._ro.observe(this);
      load();
      this._render();
    }
    disconnectedCallback() {
      subs.delete(this._subFn);
      this.removeEventListener('pointerenter', this._subFn);
      this.removeEventListener('dragenter', this);
      this.removeEventListener('dragover', this);
      this.removeEventListener('dragleave', this);
      this.removeEventListener('drop', this);
      if (this._ro) {
        this._ro.disconnect();
        this._ro = null;
      }
      // commit=false: a disconnect is not a user intent — committing here
      // would persist whatever half-finished drag a React remount or DOM
      // splice happened to interrupt. Deliberate exits commit on their own
      // paths (Escape/click-out/toggle), and unloads commit via pagehide.
      this._exitReframe(false);
    }
    _enterReframe() {
      if (this.hasAttribute('data-reframe')) return;
      this.setAttribute('data-reframe', '');
      this._signalReframe(true);
      // Best-effort commit when the document unloads mid-reframe (a host
      // navigation racing the enter signal, a manual reload, tab close):
      // the sidecar write rides the host bridge, which outlives this
      // document, so the crop survives even though the mode dies with the
      // DOM. Held on the instance so _exitReframe detaches exactly what
      // was attached.
      this._pagehide = () => {
        this._exitReframe(true);
        flushNow();
      };
      window.addEventListener('pagehide', this._pagehide);
      // Promote spill to the top layer, then keep it pinned over the frame:
      // scroll/resize cover the common cases, and a per-frame rect check
      // catches layout shifts that fire neither (an image above finishing
      // load, streamed DOM pushing the slot down, an ancestor transform
      // change) so the overlay can't detach from the frame.
      try {
        this._spill.showPopover();
      } catch {}
      // After the spill, so the controls stack above it in the top layer.
      try {
        this._ctl.showPopover();
      } catch {}
      this._reposition = () => {
        if (this.hasAttribute('data-reframe')) this._applyView();
      };
      window.addEventListener('scroll', this._reposition, true);
      window.addEventListener('resize', this._reposition);
      this._lastRect = '';
      this._watch = () => {
        if (!this.hasAttribute('data-reframe')) return;
        const r = this.getBoundingClientRect();
        const key = r.left + ',' + r.top + ',' + r.width + ',' + r.height;
        if (key !== this._lastRect) {
          this._lastRect = key;
          this._applyView();
        }
        this._watchId = requestAnimationFrame(this._watch);
      };
      this._watchId = requestAnimationFrame(this._watch);
      this._applyView();
      // Close on click outside (the spill handler stopPropagation()s so
      // in-image drags don't reach this) and on Escape. Listeners are held
      // on the instance so _exitReframe / disconnectedCallback can detach
      // exactly what was attached.
      this._outside = e => {
        if (e.composedPath && e.composedPath().includes(this)) return;
        this._exitReframe(true);
      };
      this._esc = e => {
        if (e.key === 'Escape') this._exitReframe(true);
      };
      document.addEventListener('pointerdown', this._outside, true);
      document.addEventListener('keydown', this._esc, true);
    }
    _exitReframe(commit) {
      if (!this.hasAttribute('data-reframe')) return;
      if (this._dragUp) this._dragUp();
      this.removeAttribute('data-reframe');
      this.removeAttribute('data-panning');
      if (this._outside) document.removeEventListener('pointerdown', this._outside, true);
      if (this._esc) document.removeEventListener('keydown', this._esc, true);
      this._outside = this._esc = null;
      if (this._reposition) {
        window.removeEventListener('scroll', this._reposition, true);
        window.removeEventListener('resize', this._reposition);
        this._reposition = null;
      }
      if (this._watchId) {
        cancelAnimationFrame(this._watchId);
        this._watchId = 0;
      }
      if (this._pagehide) {
        window.removeEventListener('pagehide', this._pagehide);
        this._pagehide = null;
      }
      try {
        this._spill.hidePopover();
      } catch {}
      try {
        this._ctl.hidePopover();
      } catch {}
      this._ctl.style.left = '';
      this._ctl.style.top = '';
      if (commit) this._commitView();
      this._signalReframe(false);
    }

    // Reframe state lives only in this DOM until commit, invisible to the
    // host's dirty signals — announce enter/exit so the host can hold
    // auto-reloads for exactly the gesture (the guest bundle forwards
    // image-slot:reframe to the host as imageSlotReframe). Dispatched on
    // the element (composed, so it escapes shadow roots) while connected;
    // a disconnected exit (disconnectedCallback) falls back to document so
    // the host still hears it.
    _signalReframe(active) {
      const target = this.isConnected ? this : document;
      target.dispatchEvent(new CustomEvent('image-slot:reframe', {
        bubbles: true,
        composed: true,
        detail: {
          active: active,
          id: this.id || null
        }
      }));
    }

    // Public: host's "Import from computer" calls this to run local browse.
    openFilePicker() {
      this._exitReframe(true);
      this._input.click();
    }

    // A src write is a newer intent for this slot's content — the host
    // pick path (setImageSlotImage) or an agent edit — so it must win
    // over any encode still in flight from an earlier drop: left live,
    // that encode lands later, passes _ingest's gen guard, and its
    // setSlot silently overwrites the pick (the stored value shadows
    // src in _render). Bumping _gen kills the encode before its own
    // _swapGen clear runs, so clear the dead claim here too — otherwise
    // _releaseMask (gated on !_swapGen) never fires and the pick's
    // spinner is stranded. src ONLY: the pick sets credit/credit-href
    // in the same task, and clearing _swapGen on those would let the
    // same-src branch unmask the old image mid-encode.
    attributeChangedCallback(name, oldVal, newVal) {
      if (name === 'src' && oldVal !== newVal) {
        this._gen++;
        this._swapGen = 0;
      }
      if (this.shadowRoot) this._render();
    }

    // handleEvent — one listener object for all four drag events keeps the
    // add/remove symmetric and the depth counter correct.
    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        // Without preventDefault the browser never fires 'drop'.
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        // dragenter/leave fire for every descendant crossing — count depth
        // so hovering the icon inside the empty state doesn't flicker.
        if (--this._depth <= 0) {
          this._depth = 0;
          this.removeAttribute('data-over');
        }
      } else if (e.type === 'drop') {
        e.preventDefault();
        e.stopPropagation();
        this._depth = 0;
        this.removeAttribute('data-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) this._ingest(f);
      }
    }
    async _ingest(file) {
      this._setError(null);
      if (!file || ACCEPT.indexOf(file.type) < 0) {
        this._setError('Drop a PNG, JPEG, WebP, or AVIF image.');
        return;
      }
      // toDataUrl can take hundreds of ms on a large photo. A Clear or a
      // newer drop during that window would be clobbered when this await
      // resumes — bump + capture a generation so stale encodes bail.
      const gen = ++this._gen;
      // Replacing a shown image: surface the swap through the encode too,
      // not just the decode — otherwise the old photo sits there with no
      // feedback while the canvas re-encode runs. An empty slot keeps its
      // placeholder (no spinner) until the encode lands, as before.
      // _swapGen guards the mask against re-renders DURING the encode
      // (pointerenter, ResizeObserver, another slot's store write): the
      // stored value still resolves to the old image there, so _render's
      // same-src clear would otherwise unmask it mid-replace.
      if (this.hasAttribute('data-filled')) {
        this.setAttribute('data-swapping', '');
        this._swapGen = gen;
      }
      try {
        const w = this.clientWidth || this.offsetWidth || MAX_DIM;
        const url = await toDataUrl(file, w);
        if (gen !== this._gen) return;
        // Only exit reframe once the new image is in hand — a rejected type
        // or decode failure leaves the in-progress crop untouched.
        this._exitReframe(false);
        // Clear BEFORE setSlot: its synchronous re-render must see no
        // pending encode, so a byte-identical re-upload (same data URL, no
        // load event coming) still clears the mask via the complete branch.
        this._swapGen = 0;
        const val = {
          u: url,
          s: 1,
          x: 0,
          y: 0
        };
        setSlot(this.id || '', val);
        // Keep a session-local copy for id-less slots so the drop still
        // shows, even though it cannot persist.
        if (!this.id) {
          this._local = val;
          this._render();
        }
      } catch (err) {
        if (gen !== this._gen) return;
        this._swapGen = 0;
        // Reveal the kept old image — unless another replacement (a
        // remote pick's src swap) is still in flight, in which case the
        // mask stays until THAT image settles (its load/error releases).
        this._releaseMask();
        this._setError('Could not read that image.');
        console.warn('<image-slot> ingest failed:', err);
      }
    }
    _setError(msg) {
      if (this._err) {
        this._err.remove();
        this._err = null;
      }
      if (!msg) return;
      const d = document.createElement('div');
      d.className = 'err';
      d.textContent = msg;
      this.shadowRoot.appendChild(d);
      this._err = d;
      setTimeout(() => {
        if (this._err === d) {
          d.remove();
          this._err = null;
        }
      }, 3000);
    }

    // Reframing (pan/resize) is available on any filled slot — the user can
    // always reposition/scale. `fit` only sets the initial baseline (see
    // _geom): contain starts fully-visible, cover starts frame-filling.
    _reframes() {
      return this.hasAttribute('data-filled');
    }

    // The single release discipline for the replacement-in-flight mask
    // (data-swapping). The mask comes off only when BOTH hold:
    //  - no encode is pending (_swapGen) — mid-encode the stored value
    //    still resolves to the old image, so any reveal paints it;
    //  - the frame img has settled on its current src — an unsettled src
    //    means some replacement is still in flight (e.g. a remote pick),
    //    whoever started it, and revealing would paint the previous
    //    frame. The load/error listeners pass settled=true (the event IS
    //    the settlement signal, per spec complete is true by then);
    //    other callers rely on the complete flag (covers loaded AND
    //    failed).
    // Every release path funnels through here EXCEPT _render's empty
    // branch (the img is being cleared — nothing will ever settle).
    _releaseMask(settled) {
      if (!this._swapGen && !this._loadPending && (settled || this._img.complete)) {
        this.removeAttribute('data-swapping');
      }
    }

    // Baseline geometry, shared by clamp/apply/resize. `base` is the scale at
    // view-scale s=1: cover = fill the frame (overflow on the looser axis),
    // contain = fit fully inside (letterboxed). Zooming a contain image past
    // s where it overflows naturally becomes a crop. Null until the img has
    // loaded (naturalWidth is 0 before that) or when the slot has no layout
    // box — ResizeObserver fires with a 0×0 rect under display:none, and
    // clamping against a degenerate 1×1 frame would silently pull the stored
    // pan toward zero.
    _geom() {
      const iw = this._img.naturalWidth,
        ih = this._img.naturalHeight;
      const fw = this.clientWidth,
        fh = this.clientHeight;
      if (!iw || !ih || !fw || !fh) return null;
      const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
      const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
      return {
        iw,
        ih,
        fw,
        fh,
        base
      };
    }
    _clampView() {
      // Pan range on each axis is half the overflow past the frame edge.
      const g = this._geom();
      if (!g) return;
      const mx = Math.max(0, (g.iw * g.base * this._view.s / g.fw - 1) * 50);
      const my = Math.max(0, (g.ih * g.base * this._view.s / g.fh - 1) * 50);
      this._view.x = Math.max(-mx, Math.min(mx, this._view.x));
      this._view.y = Math.max(-my, Math.min(my, this._view.y));
    }
    _applyView() {
      const g = this._geom();
      // Top-layer controls: pin to the frame's top-right in viewport px
      // (the same 8px inset as the in-frame layout; unscaled — top-layer UI
      // reads as chrome, not page content). BEFORE the geometry branch:
      // placement needs only the frame rect, and a not-yet-loaded or broken
      // src must not leave the promoted strip floating unpositioned. Gated
      // on the popover actually being open: without the Popover API,
      // showPopover() threw (swallowed in _enterReframe), .ctl stays in
      // its in-frame absolute layout, and viewport-px coordinates would
      // shove it off-frame — and matches(':popover-open') itself throws
      // there (unknown pseudo-class), hence the try/catch.
      if (this.hasAttribute('data-reframe')) {
        let onTop = false;
        try {
          onTop = this._ctl.matches(':popover-open');
        } catch {}
        if (onTop) {
          const r = this.getBoundingClientRect();
          this._ctl.style.left = r.right - 8 + 'px';
          this._ctl.style.top = r.top + 8 + 'px';
        }
      }
      if (!g) {
        // Dimensions not known yet (before img load) — centered fit so there
        // is no flash of an unpositioned image before the geometry lands.
        const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
        this._img.style.width = '100%';
        this._img.style.height = '100%';
        this._img.style.left = '50%';
        this._img.style.top = '50%';
        this._img.style.objectFit = contain ? 'contain' : 'cover';
        return;
      }
      // Baseline (cover-fill or contain-fit) × view scale. Width/height and
      // left/top are all frame-% — depends only on the frame aspect ratio, so
      // a responsive resize keeps the same crop. The spill layer mirrors the
      // same box so its corners = image corners.
      const k = g.base * this._view.s;
      const w = g.iw * k / g.fw * 100 + '%';
      const h = g.ih * k / g.fh * 100 + '%';
      const l = 50 + this._view.x + '%';
      const t = 50 + this._view.y + '%';
      this._img.style.width = w;
      this._img.style.height = h;
      this._img.style.left = l;
      this._img.style.top = t;
      this._img.style.objectFit = '';
      if (this.hasAttribute('data-reframe')) {
        // Top-layer spill: position in viewport px over the frame. The top
        // layer escapes ancestor transforms entirely, so EVERY term must be
        // in viewport units: getBoundingClientRect gives the frame's scaled
        // origin AND size, and the rect/layout ratio rescales the ghost —
        // sizing from layout px alone renders it 1/scale too large under a
        // scaled deck slide. Inner ghost + handles stay box-relative.
        const r = this.getBoundingClientRect();
        const sx = g.fw ? r.width / g.fw : 1;
        const sy = g.fh ? r.height / g.fh : 1;
        this._spill.style.width = g.iw * k * sx + 'px';
        this._spill.style.height = g.ih * k * sy + 'px';
        this._spill.style.left = r.left + (50 + this._view.x) / 100 * r.width + 'px';
        this._spill.style.top = r.top + (50 + this._view.y) / 100 * r.height + 'px';
      }
    }
    _commitView() {
      const v = {
        s: this._view.s,
        x: this._view.x,
        y: this._view.y
      };
      if (this._userUrl) v.u = this._userUrl;
      // Framing-only (no u) persists too so an author-src slot remembers its
      // crop; clearing the sidecar still falls through to src=.
      if (this.id) setSlot(this.id, v);else {
        this._local = v;
      }
    }
    _render() {
      // Shape / mask. Presets use border-radius so the dashed ring can
      // follow the rounded outline; clip-path is only applied for an
      // explicit `mask` (the ring is hidden there since a rectangle
      // dashed border chopped by an arbitrary polygon looks broken).
      const mask = this.getAttribute('mask');
      const shape = (this.getAttribute('shape') || 'rounded').toLowerCase();
      let radius = '';
      if (shape === 'circle') radius = '50%';else if (shape === 'pill') radius = '9999px';else if (shape === 'rounded') {
        const n = parseFloat(this.getAttribute('radius'));
        radius = (Number.isFinite(n) ? n : 12) + 'px';
      }
      this._frame.style.borderRadius = mask ? '' : radius;
      this._frame.style.clipPath = mask || '';
      this._ring.style.borderRadius = mask ? '' : radius;
      this._ring.style.display = mask ? 'none' : '';

      // Controls and reframe entry gate on this so share links stay read-only.
      const editable = !!(window.omelette && window.omelette.writeFile);
      this.toggleAttribute('data-editable', editable);
      this._sub.style.display = editable ? '' : 'none';

      // Content. The sidecar is also writable by the agent's write_file
      // tool, so its value isn't guaranteed canvas-originated — only accept
      // data:image/ URLs from it. The `src` attribute is author-controlled
      // (Claude wrote it into the HTML) so it passes through unchanged.
      let stored = this.id ? getSlot(this.id) : this._local;
      if (stored && stored.u && !/^data:image\//i.test(stored.u)) stored = null;
      const srcAttr = this.getAttribute('src') || '';
      this._userUrl = stored && stored.u || null;
      const url = this._userUrl || srcAttr;
      // Don't clobber an in-flight reframe with a store-triggered re-render.
      if (!this.hasAttribute('data-reframe')) {
        this._view = {
          s: stored && Number.isFinite(stored.s) ? clampS(stored.s) : 1,
          x: stored && Number.isFinite(stored.x) ? stored.x : 0,
          y: stored && Number.isFinite(stored.y) ? stored.y : 0
        };
      }
      this._cap.textContent = this.getAttribute('placeholder') || 'Drop an image';
      // Toggle via style.display — the [hidden] attribute alone loses to
      // the display:flex / display:block rules in the stylesheet above.
      // An Unsplash src with no credit attribute must NOT render — showing
      // the photo uncredited is the Unsplash-terms violation itself. The
      // error tile replaces the photo until the credit is written. A
      // user-dropped image is the user's own content and always renders.
      // Trimmed: credit is agent/user-editable content, and a whitespace-
      // only value must count as missing — otherwise it would suppress the
      // error tile AND render an empty credit box (no text, no links),
      // exactly the unattributed state this gate exists to prevent.
      const credit = (this.getAttribute('credit') || '').trim();
      const attrError = !!(!credit && !this._userUrl && srcAttr && isUnsplashHost(srcAttr));
      this.toggleAttribute('data-attribution-error', attrError);
      if (url && !attrError) {
        const prev = this._img.getAttribute('src');
        if (prev !== url) {
          // Replacing an already-shown image: mark the swap BEFORE setting
          // src so the stale frame is never revealed (see the data-swapping
          // stylesheet rules). First fill (prev empty) keeps the existing
          // placeholder-until-load behavior — no spinner. _hidShowing
          // covers the pick path's transient attribution-error wipe: prev
          // is gone, but an image WAS showing, so this is a replacement.
          if (prev || this._hidShowing) this.setAttribute('data-swapping', '');
          // Mark the swap BEFORE assigning src: complete keeps reporting
          // the old settled request until the browser's
          // update-the-image-data microtask runs, so same-task re-renders
          // (the pick path's credit/credit-href setAttributes) need this
          // flag, not complete, to know a load is in flight.
          this._loadPending = true;
          this._img.src = url;
          this._ghost.src = url;
        } else {
          // Same-src re-render — release if settled, so an ingest-set
          // spinner can't stick after a byte-identical re-upload (same
          // data URL, no further load event ever fires).
          this._releaseMask();
        }
        this._hidShowing = false;
        this._img.style.display = 'block';
        this._empty.style.display = 'none';
        this.setAttribute('data-filled', '');
        this._clampView();
        this._applyView();
      } else {
        this.removeAttribute('data-swapping');
        // The src is being removed — no load/error will ever fire for it.
        this._loadPending = false;
        // A transient attribution-error wipe of a showing image happens on
        // the pick path: the host sets src one setAttribute before credit,
        // so render N hides the old image (attrError) and render N+1
        // restores a URL. Remember the wipe so that restore renders as a
        // replacement (spinner), not a first fill (blank frame).
        this._hidShowing = attrError && !!this._img.getAttribute('src');
        this._img.style.display = 'none';
        this._img.removeAttribute('src');
        this._ghost.removeAttribute('src');
        // The error tile owns the blocked-photo state; .empty stays for
        // the genuinely-empty slot.
        this._empty.style.display = attrError ? 'none' : 'flex';
        this.removeAttribute('data-filled');
      }

      // Credit belongs to the author src, so a user drop hides it.
      // textContent + the http(s)-only funnel keep external strings inert.
      const showCredit = !!(url && credit && !this._userUrl && !attrError);
      this._credit.textContent = '';
      if (showCredit) {
        // Validate once (resolved against the document, http(s) only),
        // then append the terms-required utm referral params to links
        // that point back at unsplash.com.
        let href = '';
        const rawHref = this.getAttribute('credit-href') || '';
        if (rawHref) {
          try {
            const u = new URL(rawHref, document.baseURI);
            if (u.protocol === 'http:' || u.protocol === 'https:') {
              href = withReferral(u.href);
            }
          } catch {}
        }
        const mkLink = (text, linkHref) => {
          const a = document.createElement('a');
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener noreferrer');
          a.setAttribute('href', linkHref);
          a.textContent = text;
          return a;
        };
        // Unsplash's prescribed credit is TWO links — the photographer's
        // name to their profile (credit-href) and 'Unsplash' to the
        // homepage. Render that split whenever the text has the canonical
        // shape; other text keeps the legacy single-link rendering.
        const m = /^Photo by (.+) on Unsplash$/.exec(credit);
        if (m) {
          this._credit.appendChild(document.createTextNode('Photo by '));
          this._credit.appendChild(href ? mkLink(m[1], href) : document.createTextNode(m[1]));
          this._credit.appendChild(document.createTextNode(' on '));
          this._credit.appendChild(mkLink('Unsplash', UNSPLASH_HOMEPAGE_HREF));
        } else if (href) {
          this._credit.appendChild(mkLink(credit, href));
        } else {
          this._credit.textContent = credit;
        }
      }
      this.toggleAttribute('data-credit', showCredit);
    }
  }
  if (!customElements.get('image-slot')) {
    customElements.define('image-slot', ImageSlot);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/image-slot.js", error: String((e && e.message) || e) }); }

// ui_kits/website/shared.jsx
try { (() => {
const DS = window.DataDashDesignSystem_9ac7b0;
const PARTNER_URL = 'https://partners.datacrazy.io/partners/ian-felipe-amaral-oliveira-silva-b2f10b';
const LINKEDIN_URL = 'https://www.linkedin.com/in/ian-felipe-silva/';
function useInView(ref, opts) {
  const [v, setV] = React.useState(false);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        setV(true);
        io.disconnect();
      }
    }, {
      threshold: .18,
      ...opts
    });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return v;
}
function Reveal({
  children,
  delay = 0,
  as = 'div',
  className = '',
  style
}) {
  const r = React.useRef(null);
  const v = useInView(r);
  return React.createElement(as, {
    ref: r,
    className: 'rv ' + (v ? 'in ' : '') + className,
    style: {
      transitionDelay: delay + 'ms',
      ...style
    }
  }, children);
}
function SecHead({
  eyebrow,
  title,
  lead,
  dark
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sec-head"
  }, /*#__PURE__*/React.createElement(Reveal, {
    className: "eyebrow"
  }, eyebrow), /*#__PURE__*/React.createElement(Reveal, {
    delay: 60
  }, /*#__PURE__*/React.createElement("h2", {
    className: "h2"
  }, title)), lead ? /*#__PURE__*/React.createElement(Reveal, {
    delay: 120
  }, /*#__PURE__*/React.createElement("p", {
    className: "lead"
  }, lead)) : /*#__PURE__*/React.createElement("div", null));
}
Object.assign(window, {
  DS,
  PARTNER_URL,
  LINKEDIN_URL,
  useInView,
  Reveal,
  SecHead
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/shared.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
